/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho1;

/**
 *
 * @author Calleb Malinoski
 */
class Constantes {
    public static class Metodos{
        public final static String MARCO = "MARCO";
        public final static String POLLO = "POLLO";
        public final static String REQUEST = "REQUEST";
        public final static String RESPONSE = "RESPONSE";
        public final static String MESTRE = "MESTRE";
        public final static String SHARE = "SHARE";
        public final static String REQUISICAO = "REQUISICAO";
    }
    public static class Estados{
        public final static String HELD = "HELD";
        public final static String RELEASED = "RELEASED";
        public final static String WANTED = "WANTED";
        public final static String UNKNOW = "UNKNOW";
        public final static String DISPON = "DISPON";
        public final static String WAITING = "WAITING";
    }
}
