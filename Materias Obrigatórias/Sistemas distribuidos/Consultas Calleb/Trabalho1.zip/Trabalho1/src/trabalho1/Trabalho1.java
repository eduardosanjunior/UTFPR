package trabalho1;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.* ;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.* ;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Cipher;

public class Trabalho1 {
    public static void main(String[] args) throws Exception {
        final Processo processo = new Processo();
		Scanner scanner = new Scanner(System.in);
		System.out.println("Ola!");
		System.out.println("Vamos comecar:");
		System.out.println("Entrando no multicast...");
                //Inicia processo no multicast
		MulticastSocket multicast = new MulticastSocket(processo.multicastPORT);
		processo.group  = InetAddress.getByName(processo.multicastAddres);
		multicast.joinGroup(processo.group);
                //Thread para ouvir multicast
                Thread listenerThread = new Thread(){
			@Override
			public void run(){
                            try {
                                processo.listenMulticast(multicast);
                            } catch (Exception ex) {
                                Logger.getLogger(Trabalho1.class.getName()).log(Level.SEVERE, null, ex);
                            }
			}
		};
                
                listenerThread.start();
                System.out.println("Entramos!");
                System.out.println("Aguardando numero minimo de usuarios: " + processo.minUsuarios); 
                processo.enviaMARCO(multicast);
                
                KeyPair keyPair = Processo.buildKeyPair();
                processo.pubKey = keyPair.getPublic();
                processo.pvtKey = keyPair.getPrivate();              
                
                while( processo.membros.size() < processo.minUsuarios ){
			System.out.println("Aguardando.... Numero de usuarios: " + processo.membros.size() + " de " + processo.minUsuarios);
			Thread.sleep(2000);
		}
                Thread.sleep(2000);
                boolean running = true;
		System.out.println("Temos o minimo de usuarios!");
                System.out.println("Meu id é " + processo.id);
                processo.enviaMestre(multicast);
                processo.compartilhaChavePublica(multicast);
                
                while(running)
                {
                    Thread.sleep(2000);
                    if(processo.id.equals(processo.mestre)){
                        System.out.println("O que deseja fazer?");
                        System.out.println("1 - Mostra Chaves Públicas");
                        System.out.println("2 - Requisita horários");
                        System.out.println("3 - Sair");
                        int opt = Integer.parseInt(scanner.nextLine());
                        switch(opt)
                        {
                            case 1:
                                System.out.println(processo.chavesPub);
                                break;
                            case 2:
                                processo.requisitaHorario(multicast);
                                break;
                        }
                    }
                    else
                        System.out.println("Aguardando Mestre");
                }    
    }
}

final class Processo extends Constantes {
        //Configurações Multicast
	public String multicastAddres = "230.0.0.0";
	public int multicastPORT = 6789;
	public int minUsuarios = 2;
	public InetAddress group;
        //ID do processo
	public String id = Integer.toString((new Random().nextInt()* 50 )+1);
        private final boolean running = true;
        final static String CRLF = ",";
        //Propriedades utilizaveis do processo
        public ArrayList<String> membros = new ArrayList<>();
        public String mestre;
        public String estado = Estados.DISPON;
        public ArrayList<String> chavesPub = new ArrayList<>();
        public PublicKey pubKey;
        public PrivateKey pvtKey; 
        /*public String privateKey = Integer.toString((new Random().nextInt()));
        /*public String publicKey = Integer.toString((new Random().nextInt()));*/                
        
        public static KeyPair buildKeyPair() throws NoSuchAlgorithmException {
            final int keySize = 2048;
            KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
            keyPairGenerator.initialize(keySize);      
            return keyPairGenerator.genKeyPair();
        }
        
         public byte[] encrypt(PrivateKey privateKey, String message) throws Exception {
        Cipher cipher = Cipher.getInstance("RSA");  
        cipher.init(Cipher.ENCRYPT_MODE, privateKey);  

        return cipher.doFinal(message.getBytes());  
        }

        public byte[] decrypt(PublicKey publicKey, byte [] encrypted) throws Exception {
            Cipher cipher = Cipher.getInstance("RSA");  
            cipher.init(Cipher.DECRYPT_MODE, publicKey);

            return cipher.doFinal(encrypted);
        }
                
        public void listenMulticast(MulticastSocket multicast) throws InvalidKeySpecException, Exception{
		try{
			//System.out.println("Ouvindo multicast");
			while(this.running) {
				// Aguardando conexoes
				byte[] buffer = new byte[10*1024];
                                DatagramPacket data = new DatagramPacket(buffer, buffer.length);
				multicast.receive(data);
				//System.out.println("Chegou alguma coisa!");
				String linha = new String(buffer, 0, data.getLength());
				//System.out.println(linha);
				String[] mensagem = linha.split(CRLF);
				// Trata a mensagem
				switch(mensagem[0]){
                                        case Metodos.MARCO:
						this.respondeMARCO(mensagem, multicast);
						break;
					// Resposta para entrada no multicast
					case Metodos.POLLO:
						this.trataPOLLO(mensagem, multicast);
						break;
                                        case Metodos.MESTRE:
                                                this.trataMestre(mensagem[1]);
                                                break;
                                        case Metodos.SHARE:
                                                this.trataChavePublica(mensagem[1]);
                                                break;
                                        case Metodos.REQUISICAO:
                                                this.verificaMestre(mensagem);
                                                break;
					default:
						//System.out.println("Metodo desconhecido");
						System.out.println(mensagem[0]);
						break;
				}
			}
		}catch(IOException e){
			//System.out.println("Deu pau listenMultiCast");
			//System.out.println(e.toString());
		}
	}
        
        
        public void enviaMARCO(MulticastSocket multicast){
		try{
			//System.out.println("Mandando MARCO");
			// Envia mensagem de hello
			String mensagemDeHello = Metodos.MARCO + CRLF; // Metodo
			mensagemDeHello += this.id + CRLF; // Origem
                        DatagramPacket data = new DatagramPacket(
                                                    mensagemDeHello.getBytes(),
                                                    mensagemDeHello.length(),
                                                    this.group,
                                                    this.multicastPORT);
                        multicast.send(data);
		}catch(IOException e){
			//System.out.println(e.toString());
		}
	}
        
        private void respondeMARCO(String[] mensagem, MulticastSocket multicast){
		try{
                    //System.out.println("Respondendo MARCO");
                    // Adiciona novo membro na lista de membros
                    this.membros.add(mensagem[1]);
                    // Monta e envia resposta
                    String resposta = Metodos.POLLO + CRLF; // Metodo
                    resposta += mensagem[1] + CRLF; // Destinatario
                    resposta += this.id + CRLF; // Conteudo
                    resposta += this.id; // Origem
                    DatagramPacket data = new DatagramPacket(resposta.getBytes(),
                                                             resposta.length(),
                                                             this.group,
                                                             this.multicastPORT);
                    multicast.send(data);
		}catch(IOException e){
			//System.out.println(e.toString());
		}
	}
        
        private void trataPOLLO(String[] mensagem, MulticastSocket multicast){
		//System.out.println("Recebendo POLLO");
		try{
			// Se a mensagem eh para mim, e nao veio de mim
			if(mensagem[1].equals(this.id) && !mensagem[3].equals(this.id)){
				// Adiciona o membro na lista de membros
				this.membros.add(mensagem[2]);
			}
		}catch(Exception e){
			//System.out.println(e.toString());
		}
        }
        
        
        //O processo envia sua ID para o multicast para todos os outros processos.
        public void enviaMestre(MulticastSocket multicast)
        {
            try
            {   
                //ele só participa da eleição se ele estiver disponível, caso não haja timeout
                if(this.estado.equals(Estados.DISPON)){
                    String novoMestre = Metodos.MESTRE + CRLF;
                    novoMestre += this.id + CRLF;
                    DatagramPacket mensagem = new DatagramPacket(novoMestre.getBytes(),
                                                                 novoMestre.length(),
                                                                 this.group,
                                                                 this.multicastPORT);
                    multicast.send(mensagem);
                }
                //se não ele não participa da eleição
                else
                    System.out.println("Processo não disponível para eleição.");
            }
            catch(IOException e)
            {}
        }
        
        
        //Define o mestre dependendo da ID que recebeu
        public void trataMestre(String mestre)
        {   
            //Caso esteja vazio, ele elege o primeiro que chegou como mestre
            if(this.mestre==null)
            {
                this.mestre=mestre;
            }
            //Se a ID recebida for maior que a ID mestre definida já, ele substitui
            else if(Integer.parseInt(this.mestre) < Integer.parseInt(mestre))
            {
                this.mestre = mestre;
            }
            //System.out.println("Novo Mestre " + this.mestre);
        }
        
        public void compartilhaChavePublica(MulticastSocket multicast)
        {
            try
            {
                String chavePublica = Metodos.SHARE + CRLF;
                chavePublica += Base64.getEncoder().encodeToString(src) + CRLF;
                DatagramPacket data = new DatagramPacket (chavePublica.getBytes(),
                                                          chavePublica.length(),
                                                          this.group,
                                                          this.multicastPORT);
                multicast.send(data);
            }
            catch(Exception e)
            {
            }
        }
        
        public void trataChavePublica(String chavePublica)
        {
            this.chavesPub.add(chavePublica);
        }
        
        public void verificaMestre(String[] mensagem) throws NoSuchAlgorithmException, InvalidKeySpecException, Exception
        {   
            
            System.out.println(mensagem[1]);
            System.out.println(mensagem[2]);
             try{
                X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(mensagem[2].getBytes()));
                KeyFactory keyFactory = KeyFactory.getInstance("RSA");
                PublicKey publicKey = keyFactory.generatePublic(keySpec);
                System.out.println("this" + publicKey);
            }
            catch(Exception e)
            {}
            /*for(int i=0; i < this.chavesPub.size(); i++)
            {
                //byte[] mensagemDecript = this.decrypt(, mensagem[2].getBytes());
                //String hash = Base64.getEncoder().encodeToString(mensagemDecript);
                
                if(mensagem[1].equals(hash))
                {
                    System.out.println("Foi o mestre que enviou");
                }
                else
                {
                    System.out.println("Não o mestre que enviou");
                }
            }*/
        }
        
        
        //Ainda apenas envia o Hash Padrao, o Hash Codificado com a chave privada do mestre e a requisição
        public void requisitaHorario(MulticastSocket multicast) throws NoSuchAlgorithmException, UnsupportedEncodingException
        {
            try{
                
                //Converte a mensagem padrao num hash
                String mensagemPadrao = "Eu sou o processo mestre";
                String mensagemHex = this.retornaHash(mensagemPadrao);
                System.out.println(mensagemHex);

                //criptografa a mensagem padrão
                byte hashCript[] = this.encrypt(this.pvtKey, mensagemHex);
                String hash = Base64.getEncoder().encodeToString(hashCript);
                //System.out.println(hash);
                                
                String envioCast = Metodos.REQUISICAO + CRLF;
                envioCast += mensagemHex + CRLF;
                envioCast += hash + CRLF;
                DatagramPacket data = new DatagramPacket(envioCast.getBytes(),
                                                          envioCast.length(),
                                                          this.group,
                                                          this.multicastPORT);
                multicast.send(data);
            }
            catch(Exception e)
            {}
        }
        
        
        //Calcula o hash da mensagem padrão que será usada para verificação
        public String retornaHash(String mensagem) throws NoSuchAlgorithmException, UnsupportedEncodingException
        {
            MessageDigest algorithm = MessageDigest.getInstance("SHA-256");
            byte mensagemHash[] = algorithm.digest(mensagem.getBytes("UTF-8"));
            
            StringBuilder hexString = new StringBuilder();
            for(byte b : mensagemHash)
            {
                hexString.append(String.format("%02X", 0xFF & b));  
            }
            String mensagemHex = hexString.toString();
            return mensagemHex;
        }
}
