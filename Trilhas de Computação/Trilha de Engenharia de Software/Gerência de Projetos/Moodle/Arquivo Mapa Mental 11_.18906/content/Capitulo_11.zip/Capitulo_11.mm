<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#000000" CREATED="1344365007101" ID="ID_725255531" LINK="Figura_11_0.jpg" MODIFIED="1411582630753" TEXT="Riscos">
<font NAME="Handwriting - Dakota" SIZE="20"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties"/>
<node COLOR="#0033ff" CREATED="1348235325356" FOLDED="true" HGAP="10" ID="ID_501723022" MODIFIED="1411582630734" POSITION="right" TEXT="Conceito" VSHIFT="-50">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1348235199470" ID="ID_198712462" MODIFIED="1411582630734" TEXT="Ger. Risco =~ Ger. Projeto" VSHIFT="-3">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1348235340577" HGAP="17" ID="ID_1139779655" MODIFIED="1411582630735" TEXT="&quot;Sem n&#xfa;meros, o risco &#xe9; uma quest&#xe3;o de pura coragem&quot; (Bernstein, 1997)." VSHIFT="-1">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1348235431286" ID="ID_201042432" MODIFIED="1411582630735" TEXT="&#xca;nfase aumentada no PMBoK (+ processos)" VSHIFT="2">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1348236266322" HGAP="21" ID="ID_1358419970" MODIFIED="1411582630735" TEXT="Risco vs. Ousadia" VSHIFT="3">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1348236294797" HGAP="21" ID="ID_1337697381" MODIFIED="1411582630735" TEXT="Associa&#xe7;&#xe3;o com incerteza, probabilidade" VSHIFT="2">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1348236353510" ID="ID_403408512" MODIFIED="1411582630735" TEXT="&quot;Um evento ou condi&#xe7;&#xe3;o incerta que, se ocorrer, tem um efeito positivo ou negativo nos objetivos do projeto&quot; (PMI, 2004).">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1348236480603" ID="ID_1850487704" MODIFIED="1411582630735" TEXT="Risco: decis&#xe3;o baseada em probabilidades conhecidas">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1348236523623" HGAP="19" ID="ID_1500181185" MODIFIED="1411582630736" TEXT="Incerteza: desconhecimento de n&#xfa;meros e consequ&#xea;ncias" VSHIFT="3">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348237079387" HGAP="26" ID="ID_1216617314" MODIFIED="1411582630736" TEXT="Aleat&#xf3;ria" VSHIFT="-2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348237133636" HGAP="26" ID="ID_251121497" MODIFIED="1411582630736" TEXT="Previs&#xed;vel" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348237180234" HGAP="25" ID="ID_103141275" MODIFIED="1411582630736" TEXT="Imprevis&#xed;vel" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348237196658" HGAP="24" ID="ID_1978383560" MODIFIED="1411582630736" TEXT="Ca&#xf3;tica" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1348237607240" ID="ID_1156775784" MODIFIED="1411582630736" TEXT="Amea&#xe7;as vs. Oportunidades">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348237631833" ID="ID_1666212742" MODIFIED="1411582630736" TEXT="&quot;Quem n&#xe3;o arrisca, n&#xe3;o petisca.&quot;" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348237650094" ID="ID_1773280563" MODIFIED="1411582630736" TEXT="&quot;Prefira o certo ao duvidoso.&quot;">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1348237835145" ID="ID_1458862913" MODIFIED="1411582630736" TEXT="Vi&#xe9;s &quot;negativo&quot; (mais para amea&#xe7;as do que para oportunidades)">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1348237901621" ID="ID_987939028" MODIFIED="1411582630736" TEXT="Gest&#xe3;o de Riscos">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348237922355" ID="ID_722495378" MODIFIED="1411582630737" TEXT="Minimizar probabilidade e impacto de eventos negativos">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348237947567" ID="ID_370005699" MODIFIED="1411582630737" TEXT="Maximizar probabilidade e impacto de eventos positivos">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1348235806813" FOLDED="true" HGAP="38" ID="ID_669424451" LINK="Figura_11_1.jpg" MODIFIED="1411582630737" POSITION="right" TEXT="Processos" VSHIFT="-55">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1348235832835" HGAP="31" ID="ID_21867264" MODIFIED="1411582630738" TEXT="Planejar o gerenciamento de risco" VSHIFT="-4">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1348235845457" HGAP="33" ID="ID_253868284" MODIFIED="1411582630738" TEXT="Identificar os riscos" VSHIFT="-3">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1348235860420" HGAP="33" ID="ID_907086797" MODIFIED="1411582630738" TEXT="Realizar a an&#xe1;lise qualitativa dos riscos" VSHIFT="-5">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1348235880062" HGAP="33" ID="ID_1445234203" MODIFIED="1411582630738" TEXT="Realizar a an&#xe1;lise quantitativa dos riscos" VSHIFT="-5">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1348235904013" HGAP="33" ID="ID_1202400201" MODIFIED="1411582630738" TEXT="Planejar as respostas aos riscos" VSHIFT="2">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1348235952524" HGAP="34" ID="ID_1464607563" MODIFIED="1411582630738" TEXT="Monitorar e controlar os riscos" VSHIFT="7">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1348237994233" FOLDED="true" ID="ID_1281958520" LINK="Project%20Risk%20Managment%20Plan.doc" MODIFIED="1411582630739" POSITION="right" TEXT="Plano de Gest&#xe3;o de Risco">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1348238195215" FOLDED="true" HGAP="34" ID="ID_1662946902" MODIFIED="1411582630739" TEXT="Decis&#xf5;es" VSHIFT="-14">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348238107858" ID="ID_845461160" MODIFIED="1411582630740" TEXT="Qual &#xe9; a equipe envolvida?" VSHIFT="-2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348238129357" HGAP="21" ID="ID_351357349" MODIFIED="1411582630740" TEXT="Qual &#xe9; a abordagem mais adequada?" VSHIFT="-4">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348238159260" ID="ID_1128097786" MODIFIED="1411582630740" TEXT="Quais s&#xe3;o as fontes de dados?" VSHIFT="-9">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1348238244007" FOLDED="true" HGAP="43" ID="ID_1030003383" MODIFIED="1411582630740" TEXT="Singularidades" VSHIFT="2">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348238258666" HGAP="22" ID="ID_1576868739" MODIFIED="1411582630740" TEXT="Stakeholders com diferentes toler&#xe2;ncias ao risco" VSHIFT="3">
<font NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348238322599" ID="ID_23347680" MODIFIED="1411582630740" TEXT="Padr&#xf5;es corporativos">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1348238360906" HGAP="22" ID="ID_1710001658" MODIFIED="1411582630740" TEXT="Nomenclatura" VSHIFT="-1"/>
<node COLOR="#111111" CREATED="1348238373777" ID="ID_1868793492" MODIFIED="1411582630740" TEXT="Categorias de risco"/>
<node COLOR="#111111" CREATED="1348238387254" ID="ID_586656629" MODIFIED="1411582630740" TEXT="Templates" VSHIFT="1"/>
<node COLOR="#111111" CREATED="1348238396658" ID="ID_1537000262" MODIFIED="1411582630740" TEXT="Pap&#xe9;is e responsabilidades" VSHIFT="-2"/>
<node COLOR="#111111" CREATED="1348238441704" ID="ID_794447176" MODIFIED="1411582630740" TEXT="N&#xed;veis de autoridade" VSHIFT="2"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1348238559470" FOLDED="true" HGAP="44" ID="ID_1909083046" MODIFIED="1411582630740" TEXT="Informa&#xe7;&#xf5;es">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348238569832" HGAP="44" ID="ID_1354725466" MODIFIED="1411582630741" TEXT="M&#xe9;todo" VSHIFT="-2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348238577785" HGAP="45" ID="ID_273446837" MODIFIED="1411582630741" TEXT="Pap&#xe9;is e responsabilidades" VSHIFT="-2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348238595571" HGAP="45" ID="ID_1386575487" MODIFIED="1411582630741" TEXT="Or&#xe7;amento" VSHIFT="-4">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348238618522" HGAP="46" ID="ID_93239730" MODIFIED="1411582630741" TEXT="Estrutura anal&#xed;tica ou categorias de riscos" VSHIFT="-3">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348238686686" HGAP="46" ID="ID_1589040332" MODIFIED="1411582630741" TEXT="Frequ&#xea;ncia ao longo do ciclo de vida" VSHIFT="-4">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348238721145" HGAP="46" ID="ID_1542285488" MODIFIED="1411582630741" TEXT="Escalas de pontua&#xe7;&#xe3;o (probabilidade e impacto)" VSHIFT="-6">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348238751284" HGAP="47" ID="ID_52427394" MODIFIED="1411582630741" TEXT="Matriz de probabilidade x impacto" VSHIFT="-4">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348238774313" HGAP="50" ID="ID_1751005773" MODIFIED="1411582630741" TEXT="Limiares de exposi&#xe7;&#xe3;o ao risco" VSHIFT="-2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348238792417" HGAP="51" ID="ID_1155026119" MODIFIED="1411582630741" TEXT="Toler&#xe2;ncia ao risco dos stakeholders e diretrizes globais" VSHIFT="-3">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348238831834" HGAP="51" ID="ID_1595671353" MODIFIED="1411582630741" TEXT="Formatos de relat&#xf3;rios" VSHIFT="2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348238854627" HGAP="51" ID="ID_262468490" MODIFIED="1411582630741" TEXT="Forma de rastreamento" VSHIFT="3">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1348239040095" FOLDED="true" HGAP="17" ID="ID_1055108184" MODIFIED="1411582630742" POSITION="right" TEXT="Identifica&#xe7;&#xe3;o dos riscos" VSHIFT="72">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1348239175806" FOLDED="true" HGAP="18" ID="ID_1819626658" MODIFIED="1411582630742" TEXT="Risco (ou fator de risco)" VSHIFT="-10">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348239089236" HGAP="23" ID="ID_977158453" MODIFIED="1411582630742" TEXT="Causa" VSHIFT="2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1348239104818" HGAP="23" ID="ID_1599735989" MODIFIED="1411582630742" TEXT="Probabilidade" VSHIFT="-11"/>
</node>
<node COLOR="#990000" CREATED="1348239519911" HGAP="23" ID="ID_971162425" MODIFIED="1411582630742" TEXT="Consequ&#xea;ncia " VSHIFT="-6">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1348239532309" HGAP="21" ID="ID_1086114839" MODIFIED="1411582630742" TEXT="Impacto" VSHIFT="-12"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1348239660244" ID="ID_432173498" MODIFIED="1411582630742" TEXT="Busca de informa&#xe7;&#xf5;es hist&#xf3;ricas">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348239688617" ID="ID_607684599" MODIFIED="1411582630742" TEXT="Conhecimento de projetos anteriores" VSHIFT="-13">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1348239746364" FOLDED="true" ID="ID_33473717" MODIFIED="1411582630743" TEXT="Constru&#xe7;&#xe3;o de checklists iniciais">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348252685934" ID="ID_1797674207" MODIFIED="1411582630743" TEXT="Modelos" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348252694989" FOLDED="true" ID="ID_1875004912" MODIFIED="1411582630743" TEXT="Softwares">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1348252708815" HGAP="22" ID="ID_163165710" MODIFIED="1411582630743" TEXT="RAM" VSHIFT="-18">
<node COLOR="#111111" CREATED="1348252721204" HGAP="24" ID="ID_1145819299" MODIFIED="1411582630743" TEXT="Estrat&#xe9;gico" VSHIFT="1"/>
<node COLOR="#111111" CREATED="1348252732520" HGAP="24" ID="ID_279941562" MODIFIED="1411582630743" TEXT="Financeiro"/>
<node COLOR="#111111" CREATED="1348252743320" HGAP="24" ID="ID_940046286" MODIFIED="1411582630743" TEXT="Gest&#xe3;o de Projeto" VSHIFT="2"/>
<node COLOR="#111111" CREATED="1348252760273" HGAP="23" ID="ID_1363262186" MODIFIED="1411582630743" TEXT="Tecnol&#xf3;gico"/>
<node COLOR="#111111" CREATED="1348252777891" HGAP="23" ID="ID_1531309461" MODIFIED="1411582630743" TEXT="Operacional/Gest&#xe3;o de Mudan&#xe7;as" VSHIFT="2"/>
</node>
</node>
<node COLOR="#990000" CREATED="1348253192433" FOLDED="true" HGAP="23" ID="ID_1634319713" MODIFIED="1411582630743" TEXT="T&#xe9;cnicas" VSHIFT="33">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1348253200758" HGAP="21" ID="ID_1401777552" MODIFIED="1411582630743" TEXT="Brainstorming" VSHIFT="-1"/>
<node COLOR="#111111" CREATED="1348253279643" HGAP="19" ID="ID_1863343102" MODIFIED="1411582630743" TEXT="M&#xe9;todo Delphi (converg&#xea;ncia a partir de respostas de especialistas)" VSHIFT="2"/>
<node COLOR="#111111" CREATED="1348253321100" FOLDED="true" HGAP="19" ID="ID_1272010637" MODIFIED="1411582630743" TEXT="An&#xe1;lise SWOT" VSHIFT="2">
<node COLOR="#111111" CREATED="1348253696721" HGAP="21" ID="ID_573500797" MODIFIED="1411582630743" TEXT="Pontos fortes" VSHIFT="2"/>
<node COLOR="#111111" CREATED="1348253706923" HGAP="22" ID="ID_694864281" MODIFIED="1411582630743" TEXT="Pontos fracos">
<arrowlink DESTINATION="ID_694864281" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Arrow_ID_1982550428" STARTARROW="None" STARTINCLINATION="0;0;"/>
</node>
<node COLOR="#111111" CREATED="1348253718263" ID="ID_1537521338" MODIFIED="1411582630744" TEXT="Oportunidades"/>
<node COLOR="#111111" CREATED="1348253728578" HGAP="21" ID="ID_971329999" MODIFIED="1411582630744" TEXT="Amea&#xe7;as" VSHIFT="2"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1348253968778" FOLDED="true" ID="ID_1138417013" MODIFIED="1411582630744" TEXT="Elabora&#xe7;&#xe3;o de lista de riscos que podem afetar os objetivos do projeto" VSHIFT="12">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348254027167" ID="ID_982028965" MODIFIED="1411582630744" TEXT="como resultado de &lt;causa&gt;, pode ocorrer &lt;evento incerto&gt;, o que acarretaria &lt;consequ&#xea;ncia nos objetivos&gt;." VSHIFT="-22">
<font ITALIC="true" NAME="SansSerif" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1348495071230" FOLDED="true" HGAP="39" ID="ID_1044176672" MODIFIED="1411582630744" POSITION="left" TEXT="Monitorar e controlar riscos" VSHIFT="-39">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1348495104248" ID="ID_1193059893" MODIFIED="1411582630744" TEXT="Processo cont&#xed;nuo">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1348495124280" ID="ID_1198403688" MODIFIED="1411582630744" TEXT="Rastreamento e acompanhamento ao longo do ciclo de vida" VSHIFT="-2">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1348495224197" ID="ID_127572647" MODIFIED="1411582630745" TEXT="Execu&#xe7;&#xe3;o de planos de resposta; avalia&#xe7;&#xe3;o de efic&#xe1;cia">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1348495260884" ID="ID_1548911528" MODIFIED="1411582630745" TEXT="Gest&#xe3;o do fundo de conting&#xea;ncia" VSHIFT="2">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1348495295567" ID="ID_658018419" MODIFIED="1411582630745" TEXT="Comunica&#xe7;&#xe3;o com stakeholders">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1348495308146" ID="ID_1292210374" MODIFIED="1411582630745" TEXT="Integra&#xe7;&#xe3;o com outras &#xe1;reas" VSHIFT="1">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1348259804212" FOLDED="true" HGAP="51" ID="ID_378689023" LINK="Tabela_11_4.jpg" MODIFIED="1411582630746" POSITION="left" TEXT="Estrat&#xe9;gias de resposta" VSHIFT="-57">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1348493746990" HGAP="21" ID="ID_1117478334" MODIFIED="1411582630746" TEXT="Evitar" VSHIFT="1">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348493822181" HGAP="23" ID="ID_821629768" MODIFIED="1411582630746" TEXT="Eliminar causa-raiz no planejamento" VSHIFT="-11">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1348493759023" ID="ID_779896052" MODIFIED="1411582630747" TEXT="Transferir">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348493847684" HGAP="23" ID="ID_199752726" MODIFIED="1411582630747" TEXT="Impacto para terceiros" VSHIFT="-9">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1348493767246" HGAP="22" ID="ID_1385645268" MODIFIED="1411582630747" TEXT="Mitigar" VSHIFT="1">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348493890468" HGAP="25" ID="ID_1410246006" MODIFIED="1411582630747" TEXT="Plano de resposta para reduzir impacto/probabilidade" VSHIFT="-12">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1348493787305" ID="ID_1171327256" MODIFIED="1411582630747" TEXT="Aceitar">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348493935186" HGAP="25" ID="ID_1360541889" MODIFIED="1411582630747" TEXT="Postura reativa (ativa ou passiva)" VSHIFT="-10">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1348493800534" ID="ID_225272878" MODIFIED="1411582630747" TEXT="Explorar">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348493986971" HGAP="24" ID="ID_769510053" MODIFIED="1411582630747" TEXT="Eliminar incertezas para ocorrer" VSHIFT="-9">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1348493807374" HGAP="19" ID="ID_966664340" MODIFIED="1411582630747" TEXT="Compartilhar" VSHIFT="5">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348494838894" HGAP="19" ID="ID_473074624" MODIFIED="1411582630748" TEXT="Parceiros para compartilhar benef&#xed;cios" VSHIFT="-7">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1348493813180" HGAP="23" ID="ID_126133065" MODIFIED="1411582630748" TEXT="Real&#xe7;ar" VSHIFT="-1">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348494873050" HGAP="23" ID="ID_467695948" MODIFIED="1411582630748" TEXT="Identificar causas para maximizar impacto/probabilidade" VSHIFT="-9">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1348256728806" FOLDED="true" HGAP="60" ID="ID_311953037" LINK="Figura_11_4.jpg" MODIFIED="1411582630749" POSITION="left" TEXT="An&#xe1;lise de riscos" VSHIFT="11">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1348256855996" FOLDED="true" HGAP="19" ID="ID_1842205079" MODIFIED="1411582630749" TEXT="An&#xe1;lise qualitativa" VSHIFT="-8">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348256899354" HGAP="19" ID="ID_1918530466" MODIFIED="1411582630749" TEXT="Prioriza&#xe7;&#xe3;o de riscos segundo potencial de impacto">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348256949890" HGAP="19" ID="ID_809814833" MODIFIED="1411582630749" TEXT="Revis&#xe3;o ao longo do ciclo de vida do projeto">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348257284996" ID="ID_1736647013" LINK="Figura_11_7.jpg" MODIFIED="1411582630749" TEXT="Matriz de probabilidade e impacto">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1348257740825" HGAP="22" ID="ID_1768529050" LINK="686_01.jpeg" MODIFIED="1411582630749" TEXT="Zonas de severidade" VSHIFT="5"/>
<node COLOR="#111111" CREATED="1348258433066" ID="ID_811399156" MODIFIED="1411582630749" TEXT="Acordo sem&#xe2;ntico">
<node COLOR="#111111" CREATED="1348258196230" ID="ID_485722153" LINK="escalaimpacto.jpeg" MODIFIED="1411582630749" TEXT="Escala de impacto" VSHIFT="-16"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1348258760588" FOLDED="true" ID="ID_554046946" MODIFIED="1411582630750" TEXT="An&#xe1;lise quantitativa">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348258783124" HGAP="18" ID="ID_500672868" MODIFIED="1411582630750" TEXT="An&#xe1;lise de sensibilidade" VSHIFT="-2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348258802720" ID="ID_27575579" MODIFIED="1411582630750" TEXT="An&#xe1;lise do valor monet&#xe1;rio esperado (EVM)">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348258834017" ID="ID_387770896" LINK="Figura_11_8.jpg" MODIFIED="1411582630750" TEXT="&#xc1;rvore de decis&#xe3;o" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348259037206" ID="ID_198250301" MODIFIED="1411582630750" TEXT="Modelagem e simula&#xe7;&#xe3;o" VSHIFT="2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1348259457374" HGAP="23" ID="ID_1458646838" LINK="Figura_11_9.jpg" MODIFIED="1411582630750" TEXT="Monte Carlo" VSHIFT="-23"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1348254204423" FOLDED="true" HGAP="35" ID="ID_814763752" LINK="Figura_11_3.jpg" MODIFIED="1411582630751" POSITION="left" TEXT="Categorias de riscos" VSHIFT="76">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1348254268492" FOLDED="true" ID="ID_1790412097" LINK="Risco_tecnico.jpg" MODIFIED="1411582630751" TEXT="Riscos T&#xe9;cnicos" VSHIFT="-6">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348255048526" HGAP="19" ID="ID_1773461448" MODIFIED="1411582630751" TEXT="Uso de tecnologia n&#xe3;o provada, complexa">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348255082838" HGAP="19" ID="ID_386202259" MODIFIED="1411582630751" TEXT="Exig&#xea;ncia por metas n&#xe3;o realistas de desempenho" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348255120066" ID="ID_61871001" MODIFIED="1411582630751" TEXT="Mudan&#xe7;as na tecnologia ou normas">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1348254277448" FOLDED="true" ID="ID_1671283559" LINK="Riscos_gestao.jpg" MODIFIED="1411582630752" TEXT="Riscos da Gest&#xe3;o do Projeto" VSHIFT="-3">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348255157313" HGAP="18" ID="ID_377212314" MODIFIED="1411582630752" TEXT="Aloca&#xe7;&#xe3;o de tempos e recursos" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348255184517" ID="ID_1001072302" MODIFIED="1411582630752" TEXT="Planejamento de baixa qualidade">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348255202383" ID="ID_93997577" MODIFIED="1411582630752" TEXT="Uso inadequado de m&#xe9;todos e ferramentas de GP">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348255221914" ID="ID_456343567" MODIFIED="1411582630752" TEXT="Estimativas irrealistas/incompletas">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348255240724" ID="ID_1275529448" MODIFIED="1411582630752" TEXT="Problemas com fornecedores/subcontratantes">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348255263594" ID="ID_1848806167" MODIFIED="1411582630752" TEXT="Problemas de comunica&#xe7;&#xe3;o">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348255275271" ID="ID_1411587467" MODIFIED="1411582630752" TEXT="Inabilidade para tomada de decis&#xf5;es">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1348254291656" FOLDED="true" ID="ID_1175454738" LINK="Riscos_organizacionais.jpg" MODIFIED="1411582630752" TEXT="Riscos da Organiza&#xe7;&#xe3;o" VSHIFT="1">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348255394669" HGAP="25" ID="ID_1255990283" MODIFIED="1411582630752" TEXT="Objetivos incoerentes">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348255409496" HGAP="25" ID="ID_848261328" MODIFIED="1411582630752" TEXT="Falta de prioriza&#xe7;&#xe3;o de projetos" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348255445462" HGAP="25" ID="ID_984008494" MODIFIED="1411582630753" TEXT="Financiamento inadequado/interrompido" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348255469054" HGAP="25" ID="ID_664644717" MODIFIED="1411582630753" TEXT="Conflitos sobre recursos" VSHIFT="-8">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1348254308778" FOLDED="true" ID="ID_1004421134" LINK="Riscos_externos.jpg" MODIFIED="1411582630753" TEXT="Riscos Externos" VSHIFT="4">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348255483454" HGAP="17" ID="ID_1920585753" MODIFIED="1411582630753" TEXT="Altera&#xe7;&#xe3;o de leis/regulamentos" VSHIFT="-2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348255502028" ID="ID_78624858" MODIFIED="1411582630753" TEXT="Mudan&#xe7;as no mercado">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348255514200" ID="ID_1404871665" MODIFIED="1411582630753" TEXT="Quest&#xf5;es trabalhistas">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348255527611" ID="ID_106327189" MODIFIED="1411582630753" TEXT="Mudan&#xe7;as de prioridades dos patrocinadores">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348255545858" ID="ID_1890455192" MODIFIED="1411582630753" TEXT="Altera&#xe7;&#xf5;es meteorol&#xf3;gicas/ambientais">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
</node>
</node>
</map>
