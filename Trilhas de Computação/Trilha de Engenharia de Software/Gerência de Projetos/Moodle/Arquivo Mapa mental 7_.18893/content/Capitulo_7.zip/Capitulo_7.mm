<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#000000" CREATED="1334066176455" ID="ID_720252830" LINK="Figura_7-0.jpg" MODIFIED="1411582504099" TEXT="Custos">
<font NAME="Handwriting - Dakota" SIZE="20"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties"/>
<node COLOR="#0033ff" CREATED="1334066285916" HGAP="15" ID="ID_609279234" MODIFIED="1411582504088" POSITION="right" TEXT="Estimativas vs. singularidade" VSHIFT="-17">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
</node>
<node COLOR="#0033ff" CREATED="1334066631867" FOLDED="true" HGAP="36" ID="ID_1770176774" LINK="Figura_7-1.jpg" MODIFIED="1411582504090" POSITION="right" TEXT="Processos" VSHIFT="7">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1334066642599" FOLDED="true" HGAP="27" ID="ID_570506976" LINK="Estimativa_de_custos.jpg" MODIFIED="1411582504090" TEXT="Estimar os custos">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1334068038351" ID="ID_1754119032" LINK="Ativos_de_processos_organizacionais.jpg" MODIFIED="1411582504090" TEXT="Levantar recursos necess&#xe1;rios para completar atividades" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1334068125629" ID="ID_415038606" LINK="cost_code.pdf" MODIFIED="1411582504090" TEXT="Utilizar c&#xf3;digos de contas">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1334070179723" ID="ID_1426780155" LINK="Categorias_de_custos.jpg" MODIFIED="1411582504090" TEXT="Categorizar custos">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1334068202659" ID="ID_475876379" LINK="Ferramentas_de_estimativa.jpg" MODIFIED="1411582504090" TEXT="Utilizar m&#xe9;todos e ferramentas">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1334066653141" FOLDED="true" HGAP="26" ID="ID_877967258" MODIFIED="1411582504091" TEXT="Determinar o or&#xe7;amento (valor agregado)" VSHIFT="-1">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1334068287101" HGAP="22" ID="ID_366714229" LINK="Figura_7-3.jpg" MODIFIED="1411582504091" TEXT="Gerar a linha de base (baseline) ou curva S" VSHIFT="2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1334079337474" ID="ID_95410958" LINK="Baseline.jpg" MODIFIED="1411582504091" TEXT="Projeto" VSHIFT="-1"/>
<node COLOR="#111111" CREATED="1334079350446" HGAP="21" ID="ID_484594797" LINK="Figura_7-4.jpg" MODIFIED="1411582504091" TEXT="Pacote de trabalho"/>
<node COLOR="#111111" CREATED="1334079361793" ID="ID_385252324" MODIFIED="1411582504091" TEXT="Atividade"/>
</node>
<node COLOR="#990000" CREATED="1334079682207" HGAP="26" ID="ID_1060004711" MODIFIED="1411582504091" TEXT="Incorporar ao Plano do Projeto" VSHIFT="-12">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1334066675257" FOLDED="true" HGAP="27" ID="ID_425146626" LINK="Controle_de_custos.jpg" MODIFIED="1411582504091" TEXT="Controlar os custos">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1334079627205" ID="ID_999729512" MODIFIED="1411582504092" TEXT="Requisitos m&#xed;nimos de fundos = baseline + reserva">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1334148521334" HGAP="22" ID="ID_425744265" MODIFIED="1411582504092" TEXT="Apontar progresso do projeto" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1334148558882" ID="ID_1351877040" MODIFIED="1411582504092" TEXT="Analisar distor&#xe7;&#xf5;es" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1334148579988" ID="ID_130011540" MODIFIED="1411582504092" TEXT="Identificar alternativas de contingenciamento" VSHIFT="-2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1334148676512" HGAP="21" ID="ID_153439565" LINK="Figura_7-10.jpg" MODIFIED="1411582504092" TEXT="Postura pr&#xf3;-ativa vs. reativa" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1334067508550" FOLDED="true" HGAP="43" ID="ID_406862408" MODIFIED="1411582504093" POSITION="right" TEXT="Relacionamento" VSHIFT="-36">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1334067533097" HGAP="21" ID="ID_860446322" MODIFIED="1411582504093" TEXT="Integra&#xe7;&#xe3;o">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1334067545484" ID="ID_10093353" MODIFIED="1411582504093" TEXT="Escopo">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1334067556216" ID="ID_1876437659" MODIFIED="1411582504093" TEXT="Tempo">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1334067581373" HGAP="21" ID="ID_143338244" MODIFIED="1411582504093" TEXT="Risco" VSHIFT="1">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1334153316506" FOLDED="true" HGAP="37" ID="ID_1425921386" MODIFIED="1411582504094" POSITION="left" TEXT="Avalia&#xe7;&#xe3;o de desempenho" VSHIFT="-28">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1334153330468" ID="ID_1583646974" MODIFIED="1411582504094" TEXT="Compara&#xe7;&#xe3;o entre projetos semelhantes" VSHIFT="-4">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1334153357762" ID="ID_500972187" MODIFIED="1411582504094" TEXT="T&#xe9;cnicas">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1334153376694" FOLDED="true" HGAP="22" ID="ID_1302177115" MODIFIED="1411582504094" TEXT="Gerenciamento de Valor Agregado (EVM)" VSHIFT="-14">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1334153457446" HGAP="23" ID="ID_1434056346" MODIFIED="1411582504094" TEXT="Valor do trabalho completado vs. Valor or&#xe7;ado"/>
<node COLOR="#111111" CREATED="1334153511469" ID="ID_1974395418" MODIFIED="1411582504094" TEXT="Avalia&#xe7;&#xe3;o peri&#xf3;dica"/>
<node COLOR="#111111" CREATED="1334153773574" FOLDED="true" ID="ID_749679179" LINK="Quadro_7-1.jpg" MODIFIED="1411582504095" TEXT="Nomenclatura">
<node COLOR="#111111" CREATED="1334154334920" HGAP="28" ID="ID_82643202" LINK="Figura_7-11.jpg" MODIFIED="1411582504095" TEXT="PV, AC, EV" VSHIFT="-2"/>
<node COLOR="#111111" CREATED="1334155882536" HGAP="28" ID="ID_215276148" LINK="Equacao_7-14.jpg" MODIFIED="1411582504095" TEXT="CPI, SPI"/>
<node COLOR="#111111" CREATED="1334155927508" HGAP="28" ID="ID_429777612" LINK="Equacao_7-18.jpg" MODIFIED="1411582504095" TEXT="Raz&#xe3;o Cr&#xed;tica (CR)" VSHIFT="3"/>
<node COLOR="#111111" CREATED="1334155963182" HGAP="28" ID="ID_24292061" LINK="Figura_7-12.jpg" MODIFIED="1411582504095" TEXT="EVA" VSHIFT="3"/>
<node COLOR="#111111" CREATED="1334156247630" HGAP="28" ID="ID_146694016" LINK="Equacao_7-19.jpg" MODIFIED="1411582504095" TEXT="ETC" VSHIFT="3"/>
<node COLOR="#111111" CREATED="1334156359838" HGAP="32" ID="ID_190175287" MODIFIED="1411582504095" TEXT="EAC" VSHIFT="5">
<node COLOR="#111111" CREATED="1334156407706" HGAP="18" ID="ID_576246106" MODIFIED="1411582504095" TEXT="Vari&#xe2;ncias tendem a ser constantes" VSHIFT="-2">
<node COLOR="#111111" CREATED="1334156464531" HGAP="18" ID="ID_1518159258" MODIFIED="1411582504095" TEXT="EAC = AC + ETC" VSHIFT="-15"/>
</node>
<node COLOR="#111111" CREATED="1334156422478" ID="ID_342033591" MODIFIED="1411582504095" TEXT="Vari&#xe2;ncias at&#xed;picas"/>
</node>
</node>
<node COLOR="#111111" CREATED="1334156065570" HGAP="24" ID="ID_266846758" LINK="Figura_7-13.jpg" MODIFIED="1411582504095" TEXT="Projetos segundo o desempenho" VSHIFT="9"/>
<node COLOR="#111111" CREATED="1334156152095" ID="ID_1904904226" MODIFIED="1411582504095" TEXT="Meta: estimativas confi&#xe1;veis e execu&#xe7;&#xe3;o precisa"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1334084537134" FOLDED="true" HGAP="48" ID="ID_2075804" MODIFIED="1411582504096" POSITION="left" TEXT="Reprograma&#xe7;&#xe3;o" VSHIFT="51">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1334084585621" HGAP="23" ID="ID_1914325700" MODIFIED="1411582504096" TEXT="Nivelamento de recursos" VSHIFT="3">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1334084599359" HGAP="21" ID="ID_1363301413" MODIFIED="1411582504096" TEXT="Compress&#xe3;o de dura&#xe7;&#xe3;o (crashing)" VSHIFT="-2">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1334084627553" ID="ID_1943596950" MODIFIED="1411582504097" TEXT="Paralelismo (fast tracking)">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1334081560058" FOLDED="true" HGAP="17" ID="ID_692781824" MODIFIED="1411582504097" POSITION="left" TEXT="Tipologia" VSHIFT="85">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1334081581760" HGAP="21" ID="ID_959904399" LINK="Figura_7-5.jpg" MODIFIED="1411582504097" TEXT="Diretos" VSHIFT="1">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1334081636008" HGAP="22" ID="ID_1284594479" MODIFIED="1411582504097" TEXT="=f(utiliza&#xe7;&#xe3;o)" VSHIFT="-12">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1334081661747" HGAP="19" ID="ID_1417699089" MODIFIED="1411582504097" TEXT="M&#xe3;o-de-obra"/>
<node COLOR="#111111" CREATED="1334081673447" ID="ID_691915998" MODIFIED="1411582504097" TEXT="Materiais" VSHIFT="-3"/>
<node COLOR="#111111" CREATED="1334082279355" HGAP="21" ID="ID_683965906" MODIFIED="1411582504098" TEXT="Subcontrata&#xe7;&#xe3;o" VSHIFT="-2"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1334081589357" ID="ID_1063885404" MODIFIED="1411582504098" TEXT="Indiretos">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1334081694520" HGAP="19" ID="ID_987863221" MODIFIED="1411582504098" TEXT="Rateados conforme contas" VSHIFT="2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1334081759579" HGAP="19" ID="ID_1917598988" MODIFIED="1411582504098" TEXT="Auditoria" VSHIFT="2"/>
<node COLOR="#111111" CREATED="1334081767071" ID="ID_941195446" MODIFIED="1411582504098" TEXT="Aluguel"/>
<node COLOR="#111111" CREATED="1334081785319" ID="ID_1232763828" MODIFIED="1411582504098" TEXT="Deprecia&#xe7;&#xe3;o"/>
</node>
<node COLOR="#990000" CREATED="1334082774268" HGAP="24" ID="ID_1945301955" MODIFIED="1411582504098" TEXT="Custo Fixo x Dura&#xe7;&#xe3;o" VSHIFT="-12">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1334081605722" ID="ID_1207400795" MODIFIED="1411582504098" TEXT="Causais">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1334081819080" HGAP="24" ID="ID_805583353" MODIFIED="1411582504099" TEXT="Espor&#xe1;dicos" VSHIFT="-15">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1334081826865" HGAP="21" ID="ID_1700854800" MODIFIED="1411582504099" TEXT="Multas" VSHIFT="-10"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1334082687904" HGAP="22" ID="ID_1918718428" LINK="Figura_7-6.jpg" MODIFIED="1411582504099" TEXT="Total" VSHIFT="11">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
</node>
</node>
</map>
