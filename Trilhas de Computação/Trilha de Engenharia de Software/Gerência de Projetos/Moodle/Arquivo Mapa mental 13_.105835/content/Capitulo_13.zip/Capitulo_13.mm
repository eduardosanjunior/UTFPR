<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#000000" CREATED="1336660361608" ID="ID_265076500" MODIFIED="1465586068448" TEXT="Stakeholders">
<font NAME="Handwriting - Dakota" SIZE="20"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties"/>
<node COLOR="#0033ff" CREATED="1465584877138" HGAP="17" ID="ID_73172282" MODIFIED="1465586687417" POSITION="right" TEXT="Defini&#xe7;&#xe3;o" VSHIFT="-105">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1465584906721" HGAP="16" ID="ID_983089461" MODIFIED="1465586103468" TEXT="Pessoas, grupos ou organiza&#xe7;&#xf5;es que podem impactar ou serem impactadas por uma decis&#xe3;o, atividade ou resultado do projeto ao longo de todo o ciclo de vida (PMI, 2013)" VSHIFT="-29">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1465585126194" HGAP="21" ID="ID_557354301" MODIFIED="1465586129406" TEXT="Gerenciamento de expectativas" VSHIFT="-10">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1465585242909" FOLDED="true" ID="ID_1476195888" MODIFIED="1465586278695" TEXT="Quest&#xf5;es potenciais">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1465585255747" ID="ID_1900872351" MODIFIED="1465586176031" TEXT="Identifica&#xe7;&#xe3;o">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1465585270193" ID="ID_1791403572" MODIFIED="1465586185535" TEXT="Coleta de informa&#xe7;&#xf5;es">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1465585282974" ID="ID_1020417438" MODIFIED="1465586195697" TEXT="Identifica&#xe7;&#xe3;o de interesses">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1465585296463" ID="ID_1332112571" MODIFIED="1465586209066" TEXT="Determina&#xe7;&#xe3;o de pontos fortes e fracos">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1465585311841" ID="ID_1584640982" MODIFIED="1465586219196" TEXT="Identifica&#xe7;&#xe3;o de estrat&#xe9;gias">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1465585594221" ID="ID_717859788" MODIFIED="1465586232281" TEXT="Previs&#xe3;o do comportamento das partes interessadas">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1465585617776" ID="ID_719156159" MODIFIED="1465586264547" TEXT="Defini&#xe7;&#xe3;o de estrat&#xe9;gia de implanta&#xe7;&#xe3;o de a&#xe7;&#xf5;es de neutraliza&#xe7;&#xe3;o das partes interessadas (contra impactos negativos no projeto)">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1336663103628" HGAP="37" ID="ID_1761010291" MODIFIED="1465586684604" POSITION="right" TEXT="Processos" VSHIFT="17">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1336663448895" FOLDED="true" HGAP="21" ID="ID_1373185461" MODIFIED="1465592093229" TEXT="Identificar as partes interessadas" VSHIFT="1">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1336663558348" HGAP="22" ID="ID_1016844316" MODIFIED="1465585781629" TEXT="Identifica, analisa e documenta" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336663565794" ID="ID_1060196480" MODIFIED="1465585838543" TEXT="Verifica n&#xed;vel de engajamento, interdepend&#xea;ncias, influ&#xea;ncia, impacto potencial no sucesso do projeto">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1336663461100" ID="ID_24161279" MODIFIED="1465585872791" TEXT="Planejar a gest&#xe3;o das partes interessadas">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1336663484736" ID="ID_1999133383" MODIFIED="1465592157437" TEXT="Gerenciar o engajamento das partes interessadas">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1336663498822" HGAP="22" ID="ID_950120573" MODIFIED="1465592084389" TEXT="Controlar o engajamento" VSHIFT="2">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1465592235875" ID="ID_1129666049" MODIFIED="1465839068788" POSITION="left" TEXT="Controlar o engajamento">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1465586483999" ID="ID_92264216" MODIFIED="1465839059357" TEXT="Monitorar os relacionamentos">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1465586502817" ID="ID_1620955437" MODIFIED="1465839072235" TEXT="Ajustar estrat&#xe9;gias e planos">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1465592162195" ID="ID_1268021539" MODIFIED="1465592170235" POSITION="left" TEXT="Gerenciar o engajamento">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1465586297267" HGAP="16" ID="ID_1578770437" MODIFIED="1465592176923" TEXT="Comunicar e trabalhar com stakeholders" VSHIFT="-4">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1465586448991" ID="ID_991594912" MODIFIED="1465592184186" TEXT="Gerenciar conflitos e quest&#xf5;es">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1465586543865" ID="ID_950222531" MODIFIED="1465592191379" TEXT="Incentivar o engajamento ao longo do ciclo de vida">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1465592201170" ID="ID_130176733" MODIFIED="1465592216239" TEXT="Matriz de avalia&#xe7;&#xe3;o do n&#xed;vel de engajamento">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1465588779840" ID="ID_1318977140" MODIFIED="1465588785506" POSITION="left" TEXT="Plano de gest&#xe3;o">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1465588827175" ID="ID_1732470328" MODIFIED="1465588832217" TEXT="Elementos">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1465588837219" ID="ID_1324041041" MODIFIED="1465588844386" TEXT="Introdu&#xe7;&#xe3;o">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1465588848073" ID="ID_1682795512" MODIFIED="1465588859518" TEXT="M&#xe9;todo de tratamento de interessados">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1465591843981" ID="ID_1634379506" MODIFIED="1465591859159" TEXT="Responsabilidades com os interessados">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1465591862584" ID="ID_300086111" MODIFIED="1465591873729" TEXT="Lista dos interessados">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1465591877866" ID="ID_1458562071" MODIFIED="1465591892361" TEXT="N&#xed;vel de engajamento das partes interessadas">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1465591899524" ID="ID_912612012" MODIFIED="1465591921628" TEXT="Avalia&#xe7;&#xe3;o das partes interessadas quanto ao interesse/poder/impacto">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1465591924603" ID="ID_1383891153" MODIFIED="1465591928230" TEXT="Plano de a&#xe7;&#xe3;o">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1465591932000" ID="ID_1509678650" MODIFIED="1465591938975" TEXT="Estrat&#xe9;gia de controle">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1465588694080" HGAP="30" ID="ID_202008144" MODIFIED="1465591837274" TEXT="Estrat&#xe9;gia" VSHIFT="51">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1465588707674" ID="ID_397495533" MODIFIED="1465588795250" TEXT="Tipo de informa&#xe7;&#xe3;o">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1465588720138" ID="ID_590783867" MODIFIED="1465588795250" TEXT="Frequ&#xea;ncia">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1465588730247" ID="ID_1848022635" MODIFIED="1465588795251" TEXT="Confidencialidade">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1465588739523" ID="ID_997147141" MODIFIED="1465588795251" TEXT="Meio">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1465588748872" ID="ID_810984071" MODIFIED="1465588795251" TEXT="Controle">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1465587155040" ID="ID_75396027" MODIFIED="1465587166506" POSITION="left" TEXT="Necessidades de informa&#xe7;&#xe3;o">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1465587371637" ID="ID_1214689404" MODIFIED="1465587380131" TEXT="Cronogramas f&#xed;sicos">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1465587384192" ID="ID_1297332753" MODIFIED="1465587399255" TEXT="Dados sobre os caminhos cr&#xed;ticos">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1465587402658" ID="ID_889746787" MODIFIED="1465587409586" TEXT="Cronogramas financeiros">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1465587768245" ID="ID_1327229924" MODIFIED="1465587787883" TEXT="Qualifica&#xe7;&#xe3;o, quantifica&#xe7;&#xe3;o dos riscos e suas poss&#xed;veis respostas">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1465587792280" ID="ID_62897088" MODIFIED="1465587814690" TEXT="WBS">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1465587825479" ID="ID_900113502" MODIFIED="1465587832407" TEXT="Indicadores de desempenho">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1465588059539" ID="ID_1345843298" MODIFIED="1465588067552" TEXT="Plano de comunica&#xe7;&#xe3;o">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1465588373386" HGAP="27" ID="ID_1307180378" MODIFIED="1465588396641" TEXT="Interessados x Tecnologia x Informa&#xe7;&#xe3;o" VSHIFT="-11">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1344371740040" HGAP="72" ID="ID_1028747227" MODIFIED="1465584848758" POSITION="left" TEXT="Stakeholders" VSHIFT="53">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1465586749285" ID="ID_210071589" MODIFIED="1465586757892" TEXT="Prim&#xe1;rios e secund&#xe1;rios">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1344371857705" HGAP="46" ID="ID_1799347430" LINK="Figura_13-1.jpg" MODIFIED="1465839165452" TEXT="Poder x Influ&#xea;ncia" VSHIFT="52">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1344371874558" ID="ID_1519957512" LINK="Figura_13-2.jpg" MODIFIED="1465839176999" TEXT="Poder x Legitimidade x Urg&#xea;ncia">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1344372011189" HGAP="23" ID="ID_598256400" MODIFIED="1411582608759" TEXT="Latente" VSHIFT="3">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1344372096782" HGAP="21" ID="ID_61775521" MODIFIED="1411582608759" TEXT="Dormente"/>
<node COLOR="#111111" CREATED="1344372121711" HGAP="21" ID="ID_219620831" MODIFIED="1411582608759" TEXT="Discricion&#xe1;rio" VSHIFT="-1"/>
<node COLOR="#111111" CREATED="1344372134063" HGAP="21" ID="ID_298090853" MODIFIED="1411582608759" TEXT="Exigente"/>
</node>
<node COLOR="#990000" CREATED="1344372022877" HGAP="19" ID="ID_1412416850" MODIFIED="1411582608759" TEXT="Espectador" VSHIFT="-4">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1344372407743" HGAP="28" ID="ID_1956976188" MODIFIED="1411582608759" TEXT="Dominante"/>
<node COLOR="#111111" CREATED="1344372427888" HGAP="29" ID="ID_1378513295" MODIFIED="1411582608759" TEXT="Dependente"/>
<node COLOR="#111111" CREATED="1344372434913" HGAP="30" ID="ID_1333926364" MODIFIED="1411582608759" TEXT="Perigoso" VSHIFT="-1"/>
</node>
<node COLOR="#990000" CREATED="1344372034410" HGAP="22" ID="ID_952905657" MODIFIED="1411582608759" TEXT="Definitivo" VSHIFT="-2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
</node>
</node>
</map>
