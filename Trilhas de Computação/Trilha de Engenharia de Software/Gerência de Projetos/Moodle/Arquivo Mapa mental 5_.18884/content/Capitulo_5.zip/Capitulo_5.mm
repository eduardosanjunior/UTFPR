<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#000000" CREATED="1331725918812" ID="ID_508491387" MODIFIED="1411582424338" TEXT="Gest&#xe3;o de Escopo">
<font NAME="Handwriting - Dakota" SIZE="20"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties"/>
<node COLOR="#0033ff" CREATED="1331732530963" HGAP="21" ID="ID_23209634" MODIFIED="1412162243192" POSITION="right" TEXT="Trabalho" VSHIFT="-68">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1331732658088" HGAP="30" ID="ID_1522128404" LINK="Figura_5-1.jpg" MODIFIED="1459796560806" TEXT="Processos" VSHIFT="-39">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1459795932697" HGAP="48" ID="ID_240763393" MODIFIED="1459795960296" TEXT="Planejar o gerenciamento do escopo" VSHIFT="9">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1331732667121" HGAP="41" ID="ID_1188823306" MODIFIED="1459796556002" TEXT="Coletar os requisitos (necessidades)" VSHIFT="-5">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1331733138522" HGAP="21" ID="ID_645970264" MODIFIED="1412162283533" TEXT="Comunica&#xe7;&#xe3;o" VSHIFT="-2">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331733196967" HGAP="22" ID="ID_697215121" MODIFIED="1412162283533" TEXT="Qualidade" VSHIFT="-2">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1331732678663" HGAP="41" ID="ID_1088543867" MODIFIED="1459796553370" TEXT="Definir o escopo (declara&#xe7;&#xe3;o)" VSHIFT="-6">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1331733265727" HGAP="24" ID="ID_986281322" MODIFIED="1412162283533" TEXT="Justificativa do projeto" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331733278969" ID="ID_6699804" MODIFIED="1412162283532" TEXT="Objetivos do projeto">
<font NAME="Handwriting - Dakota" SIZE="12"/>
<node COLOR="#111111" CREATED="1331733296137" ID="ID_1581183356" MODIFIED="1412162283532" TEXT="Prazo" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331733302560" ID="ID_1357751892" MODIFIED="1412162283532" TEXT="Custo">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331733307251" ID="ID_1069454900" MODIFIED="1412162283532" TEXT="Qualidade" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
<node COLOR="#111111" CREATED="1331733580775" HGAP="22" ID="ID_414052024" MODIFIED="1412162283531" TEXT="Produto do projeto">
<font NAME="Handwriting - Dakota" SIZE="12"/>
<node COLOR="#111111" CREATED="1331733605660" HGAP="25" ID="ID_1345725095" MODIFIED="1412162283531" TEXT="Briefing, esbo&#xe7;o" VSHIFT="-3">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331733625180" HGAP="25" ID="ID_263639958" MODIFIED="1412162283531" TEXT="Partes ou subsistemas">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
<node COLOR="#111111" CREATED="1331733668875" HGAP="23" ID="ID_1880207363" MODIFIED="1412162283531" TEXT="Alcance (o que faz parte e o que n&#xe3;o faz parte)" VSHIFT="9">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331733710916" HGAP="24" ID="ID_1373515430" MODIFIED="1412162283530" TEXT="Premissas e restri&#xe7;&#xf5;es" VSHIFT="13">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1331732691556" HGAP="41" ID="ID_1788166855" LINK="Figura_5-2a.jpg" MODIFIED="1459796548589" TEXT="Criar a Estrutura Anal&#xed;tica do Projeto (ou WBS)" VSHIFT="-6">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1331733805112" HGAP="21" ID="ID_123526191" LINK="Figura_5-3.jpg" MODIFIED="1412162283530" TEXT="Representa&#xe7;&#xe3;o hier&#xe1;rquica do trabalho" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="12"/>
<node COLOR="#111111" CREATED="1331733922890" HGAP="18" ID="ID_1824494755" MODIFIED="1412162283530" TEXT="Desagrega&#xe7;&#xe3;o (top-down)" VSHIFT="-4">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331733938719" ID="ID_295121694" MODIFIED="1412162283529" TEXT="Integra&#xe7;&#xe3;o (bottom-up)">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
<node COLOR="#111111" CREATED="1331733850585" HGAP="21" ID="ID_455738297" MODIFIED="1412162283529" TEXT="Decomposi&#xe7;&#xe3;o dos resultados principais" VSHIFT="-11">
<font NAME="Handwriting - Dakota" SIZE="12"/>
<node COLOR="#111111" CREATED="1331733978758" HGAP="28" ID="ID_1289671572" MODIFIED="1412162283528" TEXT="Pacotes de trabalho" VSHIFT="-16">
<font NAME="Handwriting - Dakota" SIZE="12"/>
<node COLOR="#111111" CREATED="1331733997647" ID="ID_1056924313" MODIFIED="1412162283528" TEXT="Objetivo">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331734009437" ID="ID_971599507" MODIFIED="1412162283528" TEXT="Entregas (deliverables)">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331734027100" ID="ID_540106336" MODIFIED="1412162283527" TEXT="Programa&#xe7;&#xe3;o (atividades)">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331734044256" HGAP="21" ID="ID_1794137203" MODIFIED="1412162283527" TEXT="Or&#xe7;amento/recursos necess&#xe1;rios" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331734061671" ID="ID_98763898" MODIFIED="1412162283527" TEXT="Responsabilidades">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1331734386405" HGAP="24" ID="ID_848772724" MODIFIED="1412162283526" TEXT="Regras" VSHIFT="7">
<font NAME="Handwriting - Dakota" SIZE="12"/>
<node COLOR="#111111" CREATED="1331734399231" HGAP="17" ID="ID_894039348" MODIFIED="1412162283526" TEXT="Caixas mutuamente excludentes" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331734431911" HGAP="17" ID="ID_1613397409" MODIFIED="1412162283526" TEXT="Usar substantivos" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331734484348" ID="ID_1067425579" MODIFIED="1412162283525" TEXT="Usar crit&#xe9;rio de decomposi&#xe7;&#xe3;o" VSHIFT="4">
<font NAME="Handwriting - Dakota" SIZE="12"/>
<node COLOR="#111111" CREATED="1331734807350" HGAP="19" ID="ID_732669498" MODIFIED="1412162283525" TEXT="Subsistemas" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331734820490" ID="ID_101532398" MODIFIED="1412162283525" TEXT="Localiza&#xe7;&#xe3;o">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331735193735" ID="ID_1298819702" MODIFIED="1412162283524" TEXT="Funcionalidade">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331735206639" ID="ID_742022539" MODIFIED="1412162283524" TEXT="Fases do ciclo de vida">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331735219238" ID="ID_1045365209" MODIFIED="1412162283524" TEXT="Compet&#xea;ncias" VSHIFT="3">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
<node COLOR="#111111" CREATED="1331735251019" ID="ID_1951940761" MODIFIED="1412162283524" TEXT="Decompor at&#xe9; unidades elementares">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331735272080" ID="ID_1984400918" MODIFIED="1412162283524" TEXT="Pacote com compet&#xea;ncias similares" VSHIFT="3">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331735408104" ID="ID_1365332902" MODIFIED="1412162283523" TEXT="Bom senso na granularidade" VSHIFT="2">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
<node COLOR="#111111" CREATED="1331734458349" HGAP="22" ID="ID_567477784" MODIFIED="1412162283523" TEXT="Passos" VSHIFT="25">
<font NAME="Handwriting - Dakota" SIZE="12"/>
<node COLOR="#111111" CREATED="1331735439718" HGAP="19" ID="ID_930660372" MODIFIED="1459796353014" TEXT="Identificar principais entregas">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331735543702" HGAP="21" ID="ID_777417240" MODIFIED="1459796351696" TEXT="Definir pacotes de trabalho para cada entrega" VSHIFT="-5">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1459796316818" ID="ID_1474747592" MODIFIED="1459796762375" TEXT="Definir crit&#xe9;rio de aceita&#xe7;&#xe3;o dos pacotes de trabalho, custo, dura&#xe7;&#xe3;o e responsabilidades">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331735572637" ID="ID_60143714" MODIFIED="1459796788727" TEXT="Detalhar atividades dos pacotes de trabalho (e.g. cronograma)" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331736694407" ID="ID_1846661967" LINK="Figura_5-4.jpg" MODIFIED="1412162283521" TEXT="Relacionar com &#xe1;reas funcionais">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
<node COLOR="#111111" CREATED="1331736461315" HGAP="23" ID="ID_959528792" MODIFIED="1412162283521" TEXT="Vantagens" VSHIFT="27">
<font NAME="Handwriting - Dakota" SIZE="12"/>
<node COLOR="#111111" CREATED="1331736469696" ID="ID_41843501" MODIFIED="1412162283520" TEXT="Visibilidade do escopo e entregas">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331736490273" ID="ID_1435963550" MODIFIED="1412162283519" TEXT="Estabelecimento de responsabilidades" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331736514325" ID="ID_359877603" MODIFIED="1412162283519" TEXT="Realiza&#xe7;&#xe3;o de estimativas (custos, recursos) bottom-up">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331736540640" ID="ID_1143488820" MODIFIED="1412162283519" TEXT="Facilidade de comunica&#xe7;&#xe3;o">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331736556131" HGAP="21" ID="ID_1156222393" MODIFIED="1412162283518" TEXT="Identifica&#xe7;&#xe3;o das fontes de risco/incertezas" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331736580689" HGAP="22" ID="ID_326843255" MODIFIED="1412162283518" TEXT="Identifica&#xe7;&#xe3;o de receptores/fornecedores de informa&#xe7;&#xe3;o" VSHIFT="2">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1331732728390" FOLDED="true" HGAP="41" ID="ID_831212180" MODIFIED="1459796801184" TEXT="Validar o escopo (aceita&#xe7;&#xe3;o)">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1331737001746" ID="ID_368681872" MODIFIED="1412162283518" TEXT="Reuni&#xe3;o de projeto">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331736926404" HGAP="21" ID="ID_387758132" MODIFIED="1412162283518" TEXT="Formaliza&#xe7;&#xe3;o de aceite pelos stakeholders" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331736978425" ID="ID_1603271551" MODIFIED="1412162283518" TEXT="Garantia de entregas e associa&#xe7;&#xe3;o a respons&#xe1;veis" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331737503117" ID="ID_953840155" MODIFIED="1412162283517" TEXT="Libera&#xe7;&#xe3;o de pagamentos" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1331732739943" FOLDED="true" HGAP="43" ID="ID_1821014872" MODIFIED="1459796795526" TEXT="Controlar o escopo (altera&#xe7;&#xf5;es)" VSHIFT="6">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1331737040740" HGAP="23" ID="ID_950359106" MODIFIED="1412162283517" TEXT="Revis&#xf5;es de projeto" VSHIFT="-14">
<font NAME="Handwriting - Dakota" SIZE="12"/>
<node COLOR="#111111" CREATED="1331737064860" HGAP="27" ID="ID_1487039187" MODIFIED="1412162283517" TEXT="Peri&#xf3;dica" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331737076818" HGAP="26" ID="ID_1472071612" MODIFIED="1412162283516" TEXT="Fase" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331737085054" HGAP="27" ID="ID_1736406218" MODIFIED="1412162283516" TEXT="Espor&#xe1;dicas">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
<node COLOR="#111111" CREATED="1331737285034" ID="ID_326493462" MODIFIED="1412162283516" TEXT="Altera&#xe7;&#xf5;es de escopo">
<font NAME="Handwriting - Dakota" SIZE="12"/>
<node COLOR="#111111" CREATED="1331737322497" HGAP="21" ID="ID_1112954884" MODIFIED="1412162283516" TEXT="Novo planejamento" VSHIFT="2">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331737373010" ID="ID_32276749" MODIFIED="1412162283515" TEXT="Revis&#xe3;o de WBS">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331737331902" ID="ID_784657098" MODIFIED="1412162283515" TEXT="An&#xe1;lise de impactos">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
<node COLOR="#111111" CREATED="1331737456441" HGAP="24" ID="ID_1551039448" MODIFIED="1412162283514" TEXT="Sistemas de controle de mudan&#xe7;a" VSHIFT="18">
<font NAME="Handwriting - Dakota" SIZE="12"/>
<node COLOR="#111111" CREATED="1331737577087" HGAP="17" ID="ID_435682350" MODIFIED="1412162283514" TEXT="Solicita&#xe7;&#xe3;o de mudan&#xe7;as (change requests)" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="12"/>
<node COLOR="#111111" CREATED="1331737623100" HGAP="21" ID="ID_1475457592" MODIFIED="1412162283513" TEXT="Detalhamento, justificativa" VSHIFT="-3">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331737644531" ID="ID_252628399" MODIFIED="1412162283513" TEXT="Impactos">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
<node COLOR="#111111" CREATED="1331737673488" HGAP="21" ID="ID_971149151" MODIFIED="1412162283513" TEXT="Elementos facilitadores da an&#xe1;lise" VSHIFT="-7">
<font NAME="Handwriting - Dakota" SIZE="12"/>
<node COLOR="#111111" CREATED="1331737795979" ID="ID_1926528259" MODIFIED="1412162283512" TEXT="Prioriza&#xe7;&#xe3;o" VSHIFT="-15">
<font NAME="Handwriting - Dakota" SIZE="12"/>
<node COLOR="#111111" CREATED="1331737831260" HGAP="19" ID="ID_513846783" MODIFIED="1412162283512" TEXT="Quais s&#xe3;o as mudan&#xe7;as?" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331737842430" ID="ID_1718602554" MODIFIED="1412162283512" TEXT="Quais (n&#xe3;o) s&#xe3;o poss&#xed;veis?" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331737852983" HGAP="21" ID="ID_911001635" MODIFIED="1412162283511" TEXT="Que recursos s&#xe3;o necess&#xe1;rios?">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1331737888331" ID="ID_940678850" MODIFIED="1412162283511" TEXT="Em que prazo?">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#111111" CREATED="1331738012981" ID="ID_1140716182" MODIFIED="1412162283510" TEXT="Prepara&#xe7;&#xe3;o para planejamento">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
</node>
</node>
</node>
</node>
</map>
