<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#000000" CREATED="1334944362596" ID="ID_666984954" LINK="Figura_8-0.jpg" MODIFIED="1411582524698" TEXT="Qualidade">
<font NAME="Handwriting - Dakota" SIZE="20"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties"/>
<node COLOR="#0033ff" CREATED="1334949367033" FOLDED="true" HGAP="14" ID="ID_1336868233" MODIFIED="1411582524682" POSITION="right" TEXT="Import&#xe2;ncia" VSHIFT="-20">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1334949615944" HGAP="21" ID="ID_1015895046" MODIFIED="1411582524682" TEXT="Equivalente a custo/prazo/escopo" VSHIFT="-10">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1334949633537" ID="ID_673428697" MODIFIED="1411582524682" TEXT="Objetivo: satisfazer expectativas dos stakeholders">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1334949305133" FOLDED="true" HGAP="17" ID="ID_476238818" LINK="Figura_8-1.jpg" MODIFIED="1411582524683" POSITION="right" TEXT="Processos" VSHIFT="-11">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1334949323791" ID="ID_1167674528" MODIFIED="1411582524684" TEXT="Planejar a Qualidade" VSHIFT="2">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1334949437409" HGAP="21" ID="ID_122216209" MODIFIED="1411582524684" TEXT="Identificar padr&#xf5;es de qualidade">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1334949464934" ID="ID_86339659" MODIFIED="1411582524684" TEXT="Determinar forma de satisfazer padr&#xf5;es">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1334949336269" ID="ID_1862756709" MODIFIED="1411582524684" TEXT="Realizar a Garantia da Qualidade">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1334949548667" HGAP="21" ID="ID_1390323826" MODIFIED="1411582524684" TEXT="Aplicar atividades planejadas sistematicamente" VSHIFT="-7">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1334949349707" ID="ID_1438891733" MODIFIED="1411582524684" TEXT="Realizar o Controle da Qualidade">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1334949693580" HGAP="21" ID="ID_120396667" MODIFIED="1411582524684" TEXT="Monitorar resultados do projeto">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1334949784358" ID="ID_1602041845" MODIFIED="1411582524684" TEXT="Conferir atendimento aos padr&#xf5;es de qualidade">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1334949800765" ID="ID_290813263" MODIFIED="1411582524684" TEXT="Identificar formas de eliminar causas de desempenho insatisfat&#xf3;rio">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1334949998743" FOLDED="true" HGAP="11" ID="ID_741674726" MODIFIED="1411582524685" POSITION="right" TEXT="Abordagens" VSHIFT="-17">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1334950108451" HGAP="19" ID="ID_1387788334" MODIFIED="1411582524685" TEXT="Transcedental" VSHIFT="-5">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1334950175671" HGAP="22" ID="ID_1182941211" MODIFIED="1411582524685" TEXT="Excel&#xea;ncia inata" VSHIFT="-10">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1334950123826" ID="ID_1103046283" MODIFIED="1411582524685" TEXT="Baseada no produto" VSHIFT="-3">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1334950201586" ID="ID_737170444" MODIFIED="1411582524685" TEXT="Atributos do produto (mensur&#xe1;vel)" VSHIFT="-12">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1334950140304" ID="ID_966418922" MODIFIED="1411582524686" TEXT="Baseada no usu&#xe1;rio">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1334950227896" ID="ID_1851823557" MODIFIED="1411582524686" TEXT="Atendimento aos desejos do consumidor (subjetiva)" VSHIFT="-10">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1334950152346" ID="ID_179431634" MODIFIED="1411582524686" TEXT="Baseada na produ&#xe7;&#xe3;o" VSHIFT="4">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1334950245617" HGAP="22" ID="ID_623857874" MODIFIED="1411582524686" TEXT="Conformidade do planejado com o executado (mensur&#xe1;vel)" VSHIFT="-8">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1334950165767" HGAP="21" ID="ID_903087255" MODIFIED="1411582524686" TEXT="Baseada no valor" VSHIFT="11">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1334950412464" HGAP="22" ID="ID_962265912" MODIFIED="1411582524686" TEXT="Rela&#xe7;&#xe3;o qualidade/pre&#xe7;o" VSHIFT="-11">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1334950456424" FOLDED="true" HGAP="12" ID="ID_1815050841" MODIFIED="1411582524687" POSITION="right" TEXT="Defini&#xe7;&#xe3;o" VSHIFT="8">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1334950563889" HGAP="18" ID="ID_1947993372" MODIFIED="1411582524687" TEXT="PMBoK: caracter&#xed;sticas que traduzem a habilidade de satisfazer a necessidades" VSHIFT="-3">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1334950732868" HGAP="17" ID="ID_13497769" MODIFIED="1411582524687" TEXT="Diferencia&#xe7;&#xe3;o: qualidade do produto (depende do produto) e do projeto (abordagem PMBoK, ISO 9000)">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1334951151194" HGAP="19" ID="ID_950008963" MODIFIED="1411582524687" TEXT="Relevantes: m&#xe9;todos (TQM, 6-sigma, FMEA, Project Review, VoC, melhoria cont&#xed;nua)" VSHIFT="6">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1335103748615" FOLDED="true" HGAP="63" ID="ID_148524507" MODIFIED="1411582524688" POSITION="left" TEXT="Controle Integrado da Qualidade" VSHIFT="-49">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1335103799183" HGAP="22" ID="ID_959046557" LINK="Figura_8-19.jpg" MODIFIED="1411582524688" TEXT="Modelo Multidimensional de Desempenho de Projetos" VSHIFT="-18">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1335103836511" FOLDED="true" HGAP="30" ID="ID_1073412383" MODIFIED="1411582524688" TEXT="Integra&#xe7;&#xe3;o da Qualidade ao EVM" VSHIFT="-17">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1335103986159" HGAP="19" ID="ID_260749027" MODIFIED="1411582524688" TEXT="Desempenho do produto vs. Desempenho do gerenciamento do projeto" VSHIFT="3"/>
<node COLOR="#111111" CREATED="1335104058463" ID="ID_432465150" MODIFIED="1411582524688" TEXT="Requisitos monitorados ao longo do ciclo de vida do projeto"/>
<node COLOR="#111111" CREATED="1335104107479" HGAP="21" ID="ID_444796592" LINK="Figura_8-20.jpg" MODIFIED="1411582524688" TEXT="Fluxograma de aplica&#xe7;&#xe3;o"/>
<node COLOR="#111111" CREATED="1335104160309" ID="ID_1809305912" LINK="Figura_8-21.jpg" MODIFIED="1411582524688" TEXT="Custos e requisitos vs. WBS"/>
<node COLOR="#111111" CREATED="1335104224660" FOLDED="true" ID="ID_688596445" MODIFIED="1411582524688" TEXT="Qualidade agregada (EQ)">
<node COLOR="#111111" CREATED="1335104242266" HGAP="19" ID="ID_1330419222" LINK="Quadro_8-3.jpg" MODIFIED="1411582524688" TEXT="EQ = EV + desempenho do projeto ref. requisitos de qualidade"/>
<node COLOR="#111111" CREATED="1335104377672" ID="ID_1556954839" LINK="Figura_8-22.jpg" MODIFIED="1411582524688" TEXT="Vari&#xe2;ncia da Qualidade (QV = EQ - EV)"/>
</node>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1335042365322" FOLDED="true" HGAP="71" ID="ID_1219867282" MODIFIED="1411582524689" POSITION="left" TEXT="Mecanismos de Garantia e Controle da Qualidade" VSHIFT="-24">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1335042443390" HGAP="18" ID="ID_1222942627" MODIFIED="1411582524689" TEXT="Respons&#xe1;vel: setor da Qualidade (+ stakeholders)" VSHIFT="-2">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1335042523520" ID="ID_1401374609" MODIFIED="1411582524689" TEXT="Identificam a conformidade com pol&#xed;ticas, processos e procedimentos">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1335042498847" ID="ID_794357307" LINK="Figura_8-8.jpg" MODIFIED="1411582524689" TEXT="Resultados alimentam PDCA">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1335042592943" FOLDED="true" ID="ID_112903324" MODIFIED="1411582524689" TEXT="Auditoria da Qualidade">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1335042736326" ID="ID_1365742031" MODIFIED="1411582524689" TEXT="Exame sistem&#xe1;tico e independente" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1335042876654" ID="ID_602663720" MODIFIED="1411582524690" TEXT="Determina conformidade dos elementos do SGQ">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1335042827264" ID="ID_244843040" MODIFIED="1411582524690" TEXT="Identifica poss&#xed;veis melhorias correntes e futuras">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1335042923674" ID="ID_569394974" MODIFIED="1411582524690" TEXT="Tipos: do SGQ ou do produto; programada ou aleat&#xf3;ria">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1335043005913" FOLDED="true" ID="ID_331955585" MODIFIED="1411582524690" TEXT="Atividades preliminares">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1335043015532" HGAP="21" ID="ID_34933459" MODIFIED="1411582524690" TEXT="Identificar riscos-chave do neg&#xf3;cio" VSHIFT="2"/>
<node COLOR="#111111" CREATED="1335043825708" ID="ID_376935673" MODIFIED="1411582524690" TEXT="Avaliar processos definidos pela organiza&#xe7;&#xe3;o"/>
<node COLOR="#111111" CREATED="1335043859691" ID="ID_455579431" MODIFIED="1411582524690" TEXT="Conduzir an&#xe1;lise cr&#xed;tica da documenta&#xe7;&#xe3;o"/>
</node>
<node COLOR="#990000" CREATED="1335043884508" FOLDED="true" ID="ID_1876998226" MODIFIED="1411582524690" TEXT="Etapas">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1335043889333" ID="ID_18162239" MODIFIED="1411582524690" TEXT="Abertura" VSHIFT="1"/>
<node COLOR="#111111" CREATED="1335043897066" ID="ID_679388567" MODIFIED="1411582524690" TEXT="Coleta e exame de evid&#xea;ncias e observa&#xe7;&#xf5;es"/>
<node COLOR="#111111" CREATED="1335043932554" ID="ID_1426972374" MODIFIED="1411582524690" TEXT="Encerramento"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1335045255552" FOLDED="true" ID="ID_79092774" MODIFIED="1411582524691" TEXT="Identifica&#xe7;&#xe3;o de cauza-raiz">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1335044022588" FOLDED="true" ID="ID_1616642401" LINK="Figura_8-9.jpg" MODIFIED="1411582524691" TEXT="Diagrama de causa e efeito" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1335044073751" ID="ID_1393096473" MODIFIED="1411582524691" TEXT="(1) identificar problema a ser analisado (efeito)" VSHIFT="-1"/>
<node COLOR="#111111" CREATED="1335044154799" ID="ID_1135380097" MODIFIED="1411582524691" TEXT="(2) perguntar o que pode ter causado o problema"/>
<node COLOR="#111111" CREATED="1335044561133" ID="ID_524180824" MODIFIED="1411582524691" TEXT="(3) usar t&#xe9;cnicas de din&#xe2;mica de grupo"/>
<node COLOR="#111111" CREATED="1335044614613" ID="ID_1217863043" MODIFIED="1411582524691" TEXT="(4) aplicar t&#xe9;cnica dos 6Ms">
<node COLOR="#111111" CREATED="1335044626665" HGAP="21" ID="ID_182593969" MODIFIED="1411582524691" TEXT="Materiais" VSHIFT="3"/>
<node COLOR="#111111" CREATED="1335044636095" ID="ID_896800367" MODIFIED="1411582524691" TEXT="M&#xe9;todos"/>
<node COLOR="#111111" CREATED="1335044642912" ID="ID_1141859724" MODIFIED="1411582524691" TEXT="M&#xe1;quinas"/>
<node COLOR="#111111" CREATED="1335044652348" ID="ID_67496025" MODIFIED="1411582524691" TEXT="M&#xe3;o-de-obra"/>
<node COLOR="#111111" CREATED="1335044661330" ID="ID_1398260751" MODIFIED="1411582524691" TEXT="Meios de medi&#xe7;&#xe3;o"/>
<node COLOR="#111111" CREATED="1335044670777" HGAP="18" ID="ID_286132352" MODIFIED="1411582524691" TEXT="Meio ambiente"/>
<node COLOR="#111111" CREATED="1335044700417" ID="ID_314698102" MODIFIED="1411582524691" TEXT="+ Tempo e energia"/>
</node>
<node COLOR="#111111" CREATED="1335044738566" ID="ID_356441150" MODIFIED="1411582524692" TEXT="(5) repetir para subcausas"/>
</node>
<node COLOR="#990000" CREATED="1335044771419" FOLDED="true" ID="ID_679728622" LINK="Figura_8-10.jpg" MODIFIED="1411582524692" TEXT="DoE - Design of Experiment">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1335044803685" HGAP="23" ID="ID_395892110" MODIFIED="1411582524692" TEXT="Testes planejados" VSHIFT="1"/>
<node COLOR="#111111" CREATED="1335044813865" ID="ID_1790670567" MODIFIED="1411582524692" TEXT="Fatores (entradas) alteradas em certos n&#xed;veis para observar resposta (sa&#xed;das)"/>
<node COLOR="#111111" CREATED="1335044929042" ID="ID_655805796" MODIFIED="1411582524692" TEXT="Determina vari&#xe1;veis de maior influ&#xea;ncia sobre a resposta"/>
<node COLOR="#111111" CREATED="1335044976237" ID="ID_768964194" MODIFIED="1411582524692" TEXT="Determina ajuste das vari&#xe1;veis para resposta adequada"/>
<node COLOR="#111111" CREATED="1335045005418" ID="ID_1853109999" MODIFIED="1411582524692" TEXT="Determina ajuste das vari&#xe1;veis para resposta menos vari&#xe1;vel"/>
<node COLOR="#111111" CREATED="1335045042469" ID="ID_826742091" MODIFIED="1411582524692" TEXT="Determina ajuste das vari&#xe1;veis para minizar efeitos do ru&#xed;do (vari&#xe1;veis incontrol&#xe1;veis) sobre resposta"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1335045275084" FOLDED="true" ID="ID_112630979" MODIFIED="1411582524692" TEXT="Prioriza&#xe7;&#xe3;o de problemas">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1335045289970" FOLDED="true" HGAP="22" ID="ID_1115209238" LINK="Figura_8-12.jpg" MODIFIED="1411582524692" TEXT="Diagrama de Pareto" VSHIFT="-9">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1335045371373" ID="ID_131359136" MODIFIED="1411582524692" TEXT="80% dos defeitos relacionam-se a 20% das causas potenciais" VSHIFT="1"/>
<node COLOR="#111111" CREATED="1335045724839" ID="ID_1397120566" MODIFIED="1411582524692" TEXT="Posi&#xe7;&#xe3;o relativa das ocorr&#xea;ncias &#xe9; usada para indicar prioriza&#xe7;&#xe3;o"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1335102950336" FOLDED="true" ID="ID_1657043555" MODIFIED="1411582524693" TEXT="Utilizando m&#xe9;tricas">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1335102986502" HGAP="18" ID="ID_792734896" MODIFIED="1411582524693" TEXT="Abordagem reativa" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1335103037666" HGAP="24" ID="ID_1752143840" MODIFIED="1411582524693" TEXT="Inspe&#xe7;&#xf5;es ou revis&#xf5;es do produto" VSHIFT="-14"/>
</node>
<node COLOR="#990000" CREATED="1335103073644" HGAP="19" ID="ID_1400198688" MODIFIED="1411582524693" TEXT="Abordagem em tempo real" VSHIFT="-4">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1335103096572" HGAP="19" ID="ID_690479597" LINK="Figura_8-14.jpg" MODIFIED="1411582524693" TEXT="CEP (gr&#xe1;fico de controle)" VSHIFT="1"/>
<node COLOR="#111111" CREATED="1335103242373" FOLDED="true" ID="ID_822992824" LINK="Figura_8-15.jpg" MODIFIED="1411582524693" TEXT="Trilogia da Qualidade">
<node COLOR="#111111" CREATED="1335103264850" HGAP="19" ID="ID_433939871" MODIFIED="1411582524693" TEXT="Planejamento" VSHIFT="1"/>
<node COLOR="#111111" CREATED="1335103274380" ID="ID_654575913" MODIFIED="1411582524693" TEXT="Controle"/>
<node COLOR="#111111" CREATED="1335103280510" ID="ID_1615624917" MODIFIED="1411582524693" TEXT="Melhoria"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1335103324622" FOLDED="true" ID="ID_1987935534" MODIFIED="1411582524693" TEXT="Voz do Processo">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1335103337469" ID="ID_1926107162" LINK="Figura_8-16.jpg" MODIFIED="1411582524693" TEXT="Mapeamento" VSHIFT="-8">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1335103370690" ID="ID_1019921966" MODIFIED="1411582524693" TEXT="Pontos de coleta de dados" VSHIFT="-1"/>
<node COLOR="#111111" CREATED="1335103385451" ID="ID_465166536" MODIFIED="1411582524694" TEXT="Oportunidades de melhoria"/>
<node COLOR="#111111" CREATED="1335103396083" ID="ID_1252269935" MODIFIED="1411582524694" TEXT="Atividades sem adi&#xe7;&#xe3;o de valor"/>
<node COLOR="#111111" CREATED="1335103414769" ID="ID_595692206" MODIFIED="1411582524694" TEXT="Gargalos e inefici&#xea;ncias"/>
<node COLOR="#111111" CREATED="1335103430350" FOLDED="true" ID="ID_1084646138" MODIFIED="1411582524694" TEXT="Redesenho" VSHIFT="1">
<node COLOR="#111111" CREATED="1335103469612" HGAP="18" ID="ID_1324600859" MODIFIED="1411582524694" TEXT="Fronteiras" VSHIFT="3"/>
<node COLOR="#111111" CREATED="1335103481864" HGAP="18" ID="ID_1697056044" MODIFIED="1411582524694" TEXT="Configura&#xe7;&#xe3;o"/>
<node COLOR="#111111" CREATED="1335103494858" HGAP="17" ID="ID_714102900" MODIFIED="1411582524694" TEXT="M&#xe9;tricas"/>
<node COLOR="#111111" CREATED="1335103505129" HGAP="18" ID="ID_996126556" MODIFIED="1411582524694" TEXT="Metas de desempenho"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1335103546922" FOLDED="true" ID="ID_71153096" MODIFIED="1411582524694" TEXT="Rela&#xe7;&#xe3;o custo/benef&#xed;cio">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1335103576455" ID="ID_1899056902" LINK="Figura_8-18.jpg" MODIFIED="1411582524694" TEXT="Custo da Qualidade" VSHIFT="-11">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1335103586872" HGAP="21" ID="ID_1769413871" MODIFIED="1411582524694" TEXT="Custos de preven&#xe7;&#xe3;o"/>
<node COLOR="#111111" CREATED="1335103599709" ID="ID_780339074" MODIFIED="1411582524694" TEXT="Custos de avalia&#xe7;&#xe3;o"/>
<node COLOR="#111111" CREATED="1335103611184" ID="ID_962364918" MODIFIED="1411582524694" TEXT="Custos de falha"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1334951302017" FOLDED="true" HGAP="57" ID="ID_88058351" MODIFIED="1411582524695" POSITION="left" TEXT="Planejamento da Qualidade" VSHIFT="57">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1334951402784" ID="ID_492888064" MODIFIED="1411582524695" TEXT="Requisitos e expectativas convertidos em par&#xe2;metros de aceita&#xe7;&#xe3;o" VSHIFT="-3">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1334951531181" ID="ID_1149948354" MODIFIED="1411582524695" TEXT="Pol&#xed;ticas, procedimentos e diretrizes organizacionais">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1334951713895" HGAP="22" ID="ID_1982141524" MODIFIED="1411582524695" TEXT="Plano da Qualidade" VSHIFT="3">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1334951745370" HGAP="23" ID="ID_1643685858" MODIFIED="1411582524696" TEXT="T&#xe9;cnicas e Ferramentas" VSHIFT="6">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1334951824660" HGAP="42" ID="ID_1062500540" MODIFIED="1411582524696" TEXT="VoC" VSHIFT="11">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1334951861341" HGAP="22" ID="ID_106486069" MODIFIED="1411582524696" TEXT="Quem s&#xe3;o?" VSHIFT="2"/>
<node COLOR="#111111" CREATED="1334951881016" ID="ID_1584161120" MODIFIED="1411582524696" TEXT="Monitoramento cont&#xed;nuo"/>
<node COLOR="#111111" CREATED="1334952676842" ID="ID_151059235" MODIFIED="1411582524696" TEXT="Entrevistas, grupos focais, simula&#xe7;&#xe3;o de consumo, pesquisa de mercado"/>
<node COLOR="#111111" CREATED="1334952747456" HGAP="21" ID="ID_1227767241" LINK="Figura_8-2.jpg" MODIFIED="1411582524696" TEXT="Kano">
<node COLOR="#111111" CREATED="1334952756629" HGAP="24" ID="ID_1589068246" MODIFIED="1411582524696" TEXT="&#xcd;tens b&#xe1;sicos" VSHIFT="14">
<node COLOR="#111111" CREATED="1334952821998" HGAP="23" ID="ID_535365705" MODIFIED="1411582524696" TEXT="N&#xe3;o causa satisfa&#xe7;&#xe3;o, mas pode causar insatisfa&#xe7;&#xe3;o" VSHIFT="-13"/>
</node>
<node COLOR="#111111" CREATED="1334952767383" HGAP="19" ID="ID_1299285009" MODIFIED="1411582524696" TEXT="&#xcd;tens de desempenho" VSHIFT="-9">
<node COLOR="#111111" CREATED="1334952865551" HGAP="22" ID="ID_997401757" MODIFIED="1411582524696" TEXT="Impacto na satisfa&#xe7;&#xe3;o" VSHIFT="-12"/>
</node>
<node COLOR="#111111" CREATED="1334952777449" ID="ID_180297184" MODIFIED="1411582524696" TEXT="&#xcd;tens de encantamento">
<node COLOR="#111111" CREATED="1334952888656" HGAP="23" ID="ID_1510272675" MODIFIED="1411582524696" TEXT="Impacto exponencial na satisfa&#xe7;&#xe3;o" VSHIFT="-10"/>
</node>
</node>
<node COLOR="#111111" CREATED="1334953261452" ID="ID_1747960727" MODIFIED="1411582524696" TEXT="Rastreabilidade de requisitos">
<node COLOR="#111111" CREATED="1334953272389" HGAP="28" ID="ID_1534060398" LINK="Figura_8-3.jpg" MODIFIED="1411582524696" TEXT="QBS" VSHIFT="-9"/>
</node>
</node>
<node COLOR="#990000" CREATED="1334953337395" HGAP="40" ID="ID_1765691311" LINK="Figura_8-4.jpg" MODIFIED="1411582524697" TEXT="QFD" VSHIFT="-64">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1334953475550" HGAP="27" ID="ID_1961956101" MODIFIED="1411582524697" TEXT="Vers&#xf5;es" VSHIFT="-15">
<node COLOR="#111111" CREATED="1334953488690" HGAP="28" ID="ID_563687933" MODIFIED="1411582524697" TEXT="ASI (American Supplier Institute)" VSHIFT="-20">
<node COLOR="#111111" CREATED="1334953412313" ID="ID_1619064517" MODIFIED="1411582524697" TEXT="Casa (Matriz) da Qualidade" VSHIFT="-4"/>
<node COLOR="#111111" CREATED="1334953575170" ID="ID_1817360691" MODIFIED="1411582524697" TEXT="Partes e subconjuntos" VSHIFT="1"/>
<node COLOR="#111111" CREATED="1334953587339" ID="ID_981849589" MODIFIED="1411582524697" TEXT="Processos cr&#xed;ticos" VSHIFT="4"/>
<node COLOR="#111111" CREATED="1334953604977" ID="ID_785036292" MODIFIED="1411582524697" TEXT="M&#xe9;tricas de controle da produ&#xe7;&#xe3;o" VSHIFT="5"/>
</node>
<node COLOR="#111111" CREATED="1335041398698" ID="ID_1876210374" LINK="Figura_8-5.jpg" MODIFIED="1411582524697" TEXT="Generaliza&#xe7;&#xe3;o para Projetos">
<node COLOR="#111111" CREATED="1335041411292" HGAP="23" ID="ID_926174874" LINK="Figura_8-6.jpg" MODIFIED="1411582524697" TEXT="HoQ 1: Requisitos dos stakeholders desdobrados em CtQs" VSHIFT="5">
<node COLOR="#111111" CREATED="1335041806872" HGAP="24" ID="ID_706731675" MODIFIED="1411582524697" TEXT="Planejamento do produto: Mais importante" VSHIFT="-1"/>
<node COLOR="#111111" CREATED="1335041831770" HGAP="25" ID="ID_1757378119" MODIFIED="1411582524697" TEXT="Traduz necessidades dos stakeholders em CrQs do produto" VSHIFT="-3"/>
<node COLOR="#111111" CREATED="1335041873469" HGAP="25" ID="ID_1850002316" MODIFIED="1411582524697" TEXT="Seleciona as que maximizam satisfa&#xe7;&#xe3;o dos stakeholders"/>
<node COLOR="#111111" CREATED="1335041903208" HGAP="23" ID="ID_278088834" MODIFIED="1411582524697" TEXT="Indica concentra&#xe7;&#xe3;o de recursos em caracter&#xed;sticas chave"/>
<node COLOR="#111111" CREATED="1335041982648" HGAP="24" ID="ID_324204934" MODIFIED="1411582524697" TEXT="Possibilita benchmarking interno/externo/gen&#xe9;rico"/>
<node COLOR="#111111" CREATED="1335042044583" ID="ID_1499690879" LINK="Figura_8-7.jpg" MODIFIED="1411582524697" TEXT="Permite estabelecer metas para as CtQs"/>
</node>
<node COLOR="#111111" CREATED="1335041474548" HGAP="23" ID="ID_55015207" MODIFIED="1411582524697" TEXT="HoQ 2: CtQs desdobrados em crit&#xe9;rios de aceita&#xe7;&#xe3;o das entregas" VSHIFT="1"/>
<node COLOR="#111111" CREATED="1335041536927" HGAP="23" ID="ID_1945648732" MODIFIED="1411582524698" TEXT="HoQ 3: Cri&#xe9;rios de aceita&#xe7;&#xe3;o das entregas desdobrados em vari&#xe1;veis cr&#xed;ticas"/>
<node COLOR="#111111" CREATED="1335041670678" HGAP="23" ID="ID_1792562300" MODIFIED="1411582524698" TEXT="Resultado da HoQ 3 alimenta EVA" VSHIFT="2"/>
</node>
</node>
</node>
</node>
</node>
</node>
</map>
