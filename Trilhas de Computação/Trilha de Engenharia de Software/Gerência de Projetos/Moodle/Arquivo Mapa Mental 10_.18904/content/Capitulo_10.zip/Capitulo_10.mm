<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#000000" CREATED="1336660361608" ID="ID_265076500" LINK="Figura_10-0.jpg" MODIFIED="1411582608763" TEXT="Comunica&#xe7;&#xe3;o">
<font NAME="Handwriting - Dakota" SIZE="20"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties"/>
<node COLOR="#0033ff" CREATED="1336663103628" FOLDED="true" HGAP="17" ID="ID_1761010291" LINK="Figura_10-1.jpg" MODIFIED="1411582608751" POSITION="right" TEXT="Processos" VSHIFT="-84">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1336663448895" HGAP="21" ID="ID_1373185461" MODIFIED="1411582608752" TEXT="Identificar as partes interessadas" VSHIFT="1">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1336663558348" HGAP="22" ID="ID_1016844316" MODIFIED="1411582608752" TEXT="Pessoas" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336663565794" ID="ID_1060196480" MODIFIED="1411582608752" TEXT="Organiza&#xe7;&#xf5;es">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336663571924" HGAP="21" ID="ID_1457506823" MODIFIED="1411582608752" TEXT="N&#xed;veis de interesse" VSHIFT="2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1336663461100" ID="ID_24161279" MODIFIED="1411582608752" TEXT="Planejar as comunica&#xe7;&#xf5;es">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1336663474590" ID="ID_54861930" MODIFIED="1411582608752" TEXT="Distribuir as informa&#xe7;&#xf5;es">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1336663484736" ID="ID_1999133383" MODIFIED="1411582608752" TEXT="Gerenciar as expectativas das partes interessadas">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1336663498822" HGAP="22" ID="ID_950120573" MODIFIED="1411582608752" TEXT="Reportar o desempenho" VSHIFT="2">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1344366475640" ID="ID_716848368" LINK="Figura_10-2.jpg" MODIFIED="1411582608753" POSITION="right" TEXT="Framework de comunica&#xe7;&#xe3;o integrada">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
</node>
<node COLOR="#0033ff" CREATED="1344368975447" FOLDED="true" HGAP="-7" ID="ID_1376019048" LINK="Figura_10-3.jpg" MODIFIED="1411582608754" POSITION="right" TEXT="Processo de comunica&#xe7;&#xe3;o" VSHIFT="89">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1344370658401" HGAP="24" ID="ID_1391953483" LINK="Figura_10-4.jpg" MODIFIED="1411582608754" TEXT="Comunica&#xe7;&#xe3;o e ciclo de vida de projeto" VSHIFT="-24">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1344434341816" FOLDED="true" HGAP="21" ID="ID_1051719565" MODIFIED="1411582608755" POSITION="left" TEXT="Distribui&#xe7;&#xe3;o de informa&#xe7;&#xf5;es" VSHIFT="-50">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1344434744310" FOLDED="true" HGAP="24" ID="ID_369439061" LINK="Figura_10-13.jpg" MODIFIED="1411582608755" TEXT="Relat&#xf3;rio de desempenho" VSHIFT="-20">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1344434787229" ID="ID_1481593660" MODIFIED="1411582608755" TEXT="An&#xe1;lise da curva &quot;S&quot;" VSHIFT="2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1344434890528" HGAP="19" ID="ID_839006392" MODIFIED="1411582608755" TEXT="An&#xe1;lise dos desvios" VSHIFT="-3">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1344434906671" ID="ID_1238926669" MODIFIED="1411582608755" TEXT="Proje&#xe7;&#xe3;o dos custos finais">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1344434927410" ID="ID_1118578685" MODIFIED="1411582608755" TEXT="Maiores problemas">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1344434939288" HGAP="21" ID="ID_92785166" MODIFIED="1411582608755" TEXT="Solu&#xe7;&#xf5;es" VSHIFT="2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1344435052319" HGAP="22" ID="ID_428238331" LINK="Figura_10-12.jpg" MODIFIED="1411582608756" TEXT="Painel de controle" VSHIFT="-14">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1344373331139" FOLDED="true" HGAP="91" ID="ID_1212891613" LINK="Figura_10-10.jpg" MODIFIED="1411582608756" POSITION="left" TEXT="Plano de comunica&#xe7;&#xe3;o" VSHIFT="-78">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1344434424100" HGAP="26" ID="ID_1705353371" LINK="Figura_10-11.jpg" MODIFIED="1411582608757" TEXT="Cronogramas de reuni&#xf5;es" VSHIFT="-21">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1344372549887" FOLDED="true" HGAP="94" ID="ID_1563122182" LINK="Figura_10-8.jpg" MODIFIED="1411582608757" POSITION="left" TEXT="Planejamento" VSHIFT="-24">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1344372630225" HGAP="29" ID="ID_1807266179" MODIFIED="1411582608758" TEXT="Quem precisa de Qual informa&#xe7;&#xe3;o?" VSHIFT="2">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1344372665921" HGAP="29" ID="ID_1323164227" MODIFIED="1411582608758" TEXT="Quando eles precisar&#xe3;o?" VSHIFT="1">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1344372709301" HGAP="30" ID="ID_529920735" MODIFIED="1411582608758" TEXT="Como ela ser&#xe1; coletada, armazenada, distribu&#xed;da e atualizada?" VSHIFT="-2">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1344372816357" HGAP="30" ID="ID_1973086689" MODIFIED="1411582608758" TEXT="Por Quem?" VSHIFT="-5">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1344371740040" FOLDED="true" HGAP="72" ID="ID_1028747227" MODIFIED="1411582608758" POSITION="left" TEXT="Stakeholders" VSHIFT="53">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1344371857705" HGAP="22" ID="ID_1799347430" LINK="Figura_10-6.jpg" MODIFIED="1411582608759" TEXT="Poder x Influ&#xea;ncia" VSHIFT="-2">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1344371874558" ID="ID_1519957512" LINK="Figura_10-7.jpg" MODIFIED="1411582608759" TEXT="Poder x Legitimidade x Urg&#xea;ncia">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1344372011189" HGAP="23" ID="ID_598256400" MODIFIED="1411582608759" TEXT="Latente" VSHIFT="3">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1344372096782" HGAP="21" ID="ID_61775521" MODIFIED="1411582608759" TEXT="Dormente"/>
<node COLOR="#111111" CREATED="1344372121711" HGAP="21" ID="ID_219620831" MODIFIED="1411582608759" TEXT="Discricion&#xe1;rio" VSHIFT="-1"/>
<node COLOR="#111111" CREATED="1344372134063" HGAP="21" ID="ID_298090853" MODIFIED="1411582608759" TEXT="Exigente"/>
</node>
<node COLOR="#990000" CREATED="1344372022877" HGAP="19" ID="ID_1412416850" MODIFIED="1411582608759" TEXT="Espectador" VSHIFT="-4">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1344372407743" HGAP="28" ID="ID_1956976188" MODIFIED="1411582608759" TEXT="Dominante"/>
<node COLOR="#111111" CREATED="1344372427888" HGAP="29" ID="ID_1378513295" MODIFIED="1411582608759" TEXT="Dependente"/>
<node COLOR="#111111" CREATED="1344372434913" HGAP="30" ID="ID_1333926364" MODIFIED="1411582608759" TEXT="Perigoso" VSHIFT="-1"/>
</node>
<node COLOR="#990000" CREATED="1344372034410" HGAP="22" ID="ID_952905657" MODIFIED="1411582608759" TEXT="Definitivo" VSHIFT="-2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1344371233797" FOLDED="true" HGAP="101" ID="ID_799859545" MODIFIED="1411582608760" POSITION="left" TEXT="Causas de barreiras de comunica&#xe7;&#xe3;o" VSHIFT="76">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1344371255894" HGAP="55" ID="ID_1834879224" MODIFIED="1411582608760" TEXT="Falta de clareza na mensagem" VSHIFT="-2">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1344371272611" HGAP="53" ID="ID_1718309833" MODIFIED="1411582608760" TEXT="Mensagem mal formulada" VSHIFT="-3">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1344371290858" HGAP="54" ID="ID_1695861852" MODIFIED="1411582608760" TEXT="Conflitos entre emissor/receptor" VSHIFT="-4">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1344371306856" HGAP="55" ID="ID_1484600084" MODIFIED="1411582608760" TEXT="Premissas equivocadas/distintas entre emissor/receptor" VSHIFT="-7">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1344371347614" HGAP="56" ID="ID_770239053" MODIFIED="1411582608760" TEXT="Canais inadequados" VSHIFT="-3">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1344371417332" HGAP="56" ID="ID_1721822003" MODIFIED="1411582608761" TEXT="Excesso de informa&#xe7;&#xe3;o" VSHIFT="1">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1344371429920" HGAP="56" ID="ID_245626557" MODIFIED="1411582608761" TEXT="Ru&#xed;do excessivo" VSHIFT="4">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1344371449745" HGAP="57" ID="ID_1436197934" MODIFIED="1411582608761" TEXT="Ambiente cultural distinto entre emissor/receptor" VSHIFT="4">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1344371476372" HGAP="56" ID="ID_973251244" MODIFIED="1411582608761" TEXT="Tempo insuficiente" VSHIFT="5">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1344371496332" HGAP="56" ID="ID_377154466" MODIFIED="1411582608761" TEXT="Aus&#xea;ncia de feedback" VSHIFT="2">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1344371520742" HGAP="57" ID="ID_564188567" MODIFIED="1411582608761" TEXT="Censura da informa&#xe7;&#xe3;o transmitida" VSHIFT="5">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1344371540633" HGAP="59" ID="ID_1938968945" MODIFIED="1411582608761" TEXT="Informa&#xe7;&#xf5;es irrelevantes" VSHIFT="6">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1344370848888" FOLDED="true" HGAP="-20" ID="ID_1005708530" MODIFIED="1411582608762" POSITION="left" TEXT="Habilidades de comunica&#xe7;&#xe3;o do PM" VSHIFT="52">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1344370867544" HGAP="21" ID="ID_127618482" MODIFIED="1411582608762" TEXT="Conhecer as formas de comunica&#xe7;&#xe3;o" VSHIFT="1">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1344370886868" HGAP="22" ID="ID_1489881116" MODIFIED="1411582608762" TEXT="Planos">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1344370895328" ID="ID_1412528415" MODIFIED="1411582608762" TEXT="Relat&#xf3;rios">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1344370901877" ID="ID_551782119" MODIFIED="1411582608762" TEXT="Pol&#xed;ticas">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1344370912495" ID="ID_976573565" MODIFIED="1411582608762" TEXT="Procedimentos">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1344370922544" ID="ID_1145906318" MODIFIED="1411582608762" TEXT="Reuni&#xf5;es">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1344370932059" HGAP="19" ID="ID_850680388" MODIFIED="1411582608762" TEXT="Cartas" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1344370951423" ID="ID_1805175596" MODIFIED="1411582608763" TEXT="Entender e exercer formas de express&#xe3;o">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1344370974183" HGAP="21" ID="ID_1449457828" MODIFIED="1411582608763" TEXT="N&#xe3;o verbal" VSHIFT="2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1344370982091" ID="ID_442019347" MODIFIED="1411582608763" TEXT="Express&#xf5;es faciais">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1344370992528" ID="ID_1383429799" MODIFIED="1411582608763" TEXT="Movimentos corporais">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1344371010213" ID="ID_207521859" MODIFIED="1411582608763" TEXT="Ter senso de justi&#xe7;a">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1344371021183" ID="ID_212262287" MODIFIED="1411582608763" TEXT="Saber sintetizar ou expandir informa&#xe7;&#xf5;es">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1344371039149" ID="ID_263415565" MODIFIED="1411582608763" TEXT="Elaborar planejamento de comunica&#xe7;&#xe3;o">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1344371056982" ID="ID_1759361967" MODIFIED="1411582608763" TEXT="Conhecer as expectativas dos emissores/receptores">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1344371071225" ID="ID_1178646404" LINK="Figura_10-5.jpg" MODIFIED="1411582608763" TEXT="Conhecer os canais dispon&#xed;veis">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
</node>
</node>
</map>
