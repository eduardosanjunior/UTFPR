<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#000000" CREATED="1332333534530" ID="ID_1893959066" MODIFIED="1412162367404" TEXT="Tempo">
<font NAME="Handwriting - Dakota" SIZE="20"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties"/>
<node COLOR="#0033ff" CREATED="1332334537093" FOLDED="true" HGAP="4" ID="ID_1648867334" MODIFIED="1460400048346" POSITION="right" TEXT="Caracter&#xed;sticas" VSHIFT="-26">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1332334562428" HGAP="18" ID="ID_1755765766" MODIFIED="1412162367404" TEXT="Temporalidade">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1332334576455" ID="ID_186309111" MODIFIED="1412162367403" TEXT="Singularidade">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1332334686921" HGAP="13" ID="ID_1774791407" LINK="Figura_2-15.jpg" MODIFIED="1412162367403" POSITION="right" TEXT="Vs. Custo; Escopo" VSHIFT="-34">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
</node>
<node COLOR="#0033ff" CREATED="1332334738423" HGAP="24" ID="ID_845698330" LINK="Quadro_3-3.jpg" MODIFIED="1460400057819" POSITION="right" TEXT="Processos do PMBoK" VSHIFT="-94">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1460400004142" HGAP="28" ID="ID_374749205" MODIFIED="1460400071873" TEXT="Planejar o gerenciamento do tempo" VSHIFT="-1">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1332334757301" HGAP="29" ID="ID_757057232" MODIFIED="1412162367402" TEXT="Definir as atividades" VSHIFT="-2">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1332334770103" HGAP="30" ID="ID_596669873" MODIFIED="1412162367401" TEXT="Sequenciar as atividades" VSHIFT="-3">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1332334789306" HGAP="31" ID="ID_225621008" MODIFIED="1412162367401" TEXT="Estimar os recursos das atividades" VSHIFT="-2">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1332334811582" HGAP="30" ID="ID_1950031390" MODIFIED="1412162367401" TEXT="Estimar as dura&#xe7;&#xf5;es das atividades" VSHIFT="-5">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1332334836388" HGAP="30" ID="ID_278301798" MODIFIED="1412162367401" TEXT="Desenvolver o cronograma" VSHIFT="-4">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1332334863523" HGAP="30" ID="ID_1644454490" MODIFIED="1412162367401" TEXT="Controlar o cronograma">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1332335391850" HGAP="31" ID="ID_65926791" LINK="Figura_6-1.jpg" MODIFIED="1412162367400" POSITION="right" TEXT="Fluxograma" VSHIFT="-16">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
</node>
<node COLOR="#0033ff" CREATED="1332337116531" FOLDED="true" HGAP="59" ID="ID_329580717" MODIFIED="1460400044096" POSITION="left" TEXT="Sequenciamento de atividades" VSHIFT="107">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1334602013741" HGAP="-16" ID="ID_340648222" MODIFIED="1412162367397" TEXT="Desenvolvimento de cronograma" VSHIFT="-89">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1332337149370" HGAP="19" ID="ID_1156692829" MODIFIED="1412162367396" TEXT="Rela&#xe7;&#xf5;es de depend&#xea;ncia" VSHIFT="-9">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1332337453031" HGAP="19" ID="ID_841965250" MODIFIED="1412162367395" TEXT="Tipos" VSHIFT="-37">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1332337229031" HGAP="23" ID="ID_168753572" MODIFIED="1412162367395" TEXT="Mandat&#xf3;ria" VSHIFT="13">
<font NAME="Handwriting - Dakota" SIZE="12"/>
<node COLOR="#111111" CREATED="1332337290333" HGAP="27" ID="ID_1253617299" MODIFIED="1412162367395" TEXT="R&#xed;gida/Restritiva" VSHIFT="-18">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
<node COLOR="#111111" CREATED="1332337239100" HGAP="23" ID="ID_129393173" MODIFIED="1412162367395" TEXT="Arbitrada" VSHIFT="-4">
<font NAME="Handwriting - Dakota" SIZE="12"/>
<node COLOR="#111111" CREATED="1332337308861" HGAP="30" ID="ID_285171123" MODIFIED="1412162367394" TEXT="Baseada na experi&#xea;ncia/melhores pr&#xe1;ticas" VSHIFT="-21">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
<node COLOR="#111111" CREATED="1332337257641" HGAP="26" ID="ID_1470346047" MODIFIED="1412162367394" TEXT="Externa" VSHIFT="-18">
<font NAME="Handwriting - Dakota" SIZE="12"/>
<node COLOR="#111111" CREATED="1332337353435" HGAP="34" ID="ID_1555254834" MODIFIED="1412162367394" TEXT="Ref. atividades fora do escopo" VSHIFT="-23">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1332337431848" HGAP="21" ID="ID_823069437" MODIFIED="1412162367394" TEXT="Quanto menos, melhor" VSHIFT="2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1332337482619" ID="ID_759607552" MODIFIED="1412162367391" TEXT="Representa&#xe7;&#xe3;o">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1332337512185" HGAP="23" ID="ID_1993802219" LINK="Figura_6-3.jpg" MODIFIED="1412162367391" TEXT="Diagrama de Preced&#xea;ncia" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1332337922104" HGAP="25" ID="ID_84673347" MODIFIED="1412162367390" TEXT="Tipos de preced&#xea;ncia" VSHIFT="-19">
<font NAME="Handwriting - Dakota" SIZE="12"/>
<node COLOR="#111111" CREATED="1332337934365" HGAP="27" ID="ID_657769144" MODIFIED="1412162367390" TEXT="T&#xe9;rmino/in&#xed;cio">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1332337968588" HGAP="26" ID="ID_484828755" MODIFIED="1412162367390" TEXT="T&#xe9;rmino/t&#xe9;rmino" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1332337984180" HGAP="27" ID="ID_1808226872" MODIFIED="1412162367390" TEXT="In&#xed;cio/in&#xed;cio" VSHIFT="-2">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1332337998716" HGAP="27" ID="ID_932834495" MODIFIED="1412162367389" TEXT="In&#xed;cio/t&#xe9;rmino" VSHIFT="2">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1332337533538" HGAP="24" ID="ID_412776536" LINK="Figura_6-4.jpg" MODIFIED="1412162367389" TEXT="Diagrama de Flechas ou Arcos" VSHIFT="-9">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1332339129451" HGAP="23" ID="ID_1476991601" LINK="Tabela_6-1.jpg" MODIFIED="1412162367389" TEXT="Regras" VSHIFT="-17">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
<node COLOR="#990000" CREATED="1332337572889" HGAP="26" ID="ID_1273269007" LINK="Figura_6-5.jpg" MODIFIED="1412162367388" TEXT="Diagrama Condicional" VSHIFT="-5">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1332337590147" HGAP="26" ID="ID_481099245" LINK="800px-GanttChartAnatomy.svg.png" MODIFIED="1412162367387" TEXT="Diagrama de Gantt" VSHIFT="-1">
<arrowlink DESTINATION="ID_340648222" ENDARROW="Default" ENDINCLINATION="327;0;" ID="Arrow_ID_1522960562" STARTARROW="None" STARTINCLINATION="327;0;"/>
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1332337615886" HGAP="25" ID="ID_1801567962" LINK="MSC.png" MODIFIED="1412162367387" TEXT="Diagrama de Marcos" VSHIFT="1">
<arrowlink DESTINATION="ID_340648222" ENDARROW="Default" ENDINCLINATION="353;0;" ID="Arrow_ID_211637875" STARTARROW="None" STARTINCLINATION="353;0;"/>
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1332340314208" HGAP="26" ID="ID_1699765848" LINK="pert_hardware.gif" MODIFIED="1412162367385" TEXT="PERT e CPM" VSHIFT="4">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1332340527341" HGAP="21" ID="ID_132605667" LINK="Exercicio_6-5.jpg" MODIFIED="1412162367384" TEXT="CPM: 1 estimativa de dura&#xe7;&#xe3;o" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="12"/>
<node COLOR="#111111" CREATED="1332340777329" ID="ID_561575765" MODIFIED="1412162367384" TEXT="Experi&#xea;ncia" VSHIFT="2">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1332340799728" ID="ID_393502661" MODIFIED="1412162367384" TEXT="Dados hist&#xf3;rios ou secund&#xe1;rios">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1332340837764" ID="ID_189963752" MODIFIED="1412162367383" TEXT="Estimativas de recursos e dura&#xe7;&#xe3;o bottom-up">
<font NAME="Handwriting - Dakota" SIZE="12"/>
<node COLOR="#111111" CREATED="1332340953044" ID="ID_1566573972" MODIFIED="1412162367383" TEXT="Precisas e trabalhosas" VSHIFT="-13">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
<node COLOR="#111111" CREATED="1332340858632" ID="ID_1048655024" MODIFIED="1412162367383" TEXT="Estimativas de recursos e dura&#xe7;&#xe3;o top-down">
<font NAME="Handwriting - Dakota" SIZE="12"/>
<node COLOR="#111111" CREATED="1332340972664" HGAP="23" ID="ID_990456832" MODIFIED="1412162367383" TEXT="Por analogia" VSHIFT="-12">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
<node COLOR="#111111" CREATED="1332341111602" ID="ID_1781519078" LINK="Equacao_6-1.jpg" MODIFIED="1412162367382" TEXT="Programa&#xe7;&#xe3;o para frente: data de in&#xed;cio mais cedo" VSHIFT="4">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1332341319582" ID="ID_1205338574" LINK="Equacao_6-2.jpg" MODIFIED="1412162367382" TEXT="Programa&#xe7;&#xe3;o para tr&#xe1;s: data de t&#xe9;rmino mais tarde">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
<node COLOR="#111111" CREATED="1332340555623" ID="ID_1992590498" LINK="critical-path-method.xls" MODIFIED="1412162367381" TEXT="PERT: 3 estimativas de dura&#xe7;&#xe3;o (estoc&#xe1;stico)">
<font NAME="Handwriting - Dakota" SIZE="12"/>
<node COLOR="#111111" CREATED="1333395326285" HGAP="18" ID="ID_1211261406" MODIFIED="1412162367381" TEXT="Dura&#xe7;&#xe3;o otimista">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1333395347625" ID="ID_1942436671" MODIFIED="1412162367380" TEXT="Dura&#xe7;&#xe3;o mais prov&#xe1;vel">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1333395361752" ID="ID_1263336263" MODIFIED="1412162367380" TEXT="Dura&#xe7;&#xe3;o pessimista">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
<node COLOR="#111111" CREATED="1333395488316" ID="ID_954303096" MODIFIED="1412162367380" TEXT="Probabilidade de realiza&#xe7;&#xe3;o">
<font NAME="Handwriting - Dakota" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#990000" CREATED="1332337632526" HGAP="24" ID="ID_698898361" MODIFIED="1412162367380" TEXT="Diagrama de barras ou histograma de recursos" VSHIFT="2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1332335941506" FOLDED="true" HGAP="42" ID="ID_12571578" LINK="Figura_6-1b.jpg" MODIFIED="1460400045287" POSITION="left" TEXT="Defini&#xe7;&#xe3;o de atividades" VSHIFT="92">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1332336136785" HGAP="23" ID="ID_29132525" MODIFIED="1412162367377" TEXT="Unidade indivis&#xed;vel">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1332336152388" HGAP="25" ID="ID_1937896274" MODIFIED="1412162367377" TEXT="Recursos" VSHIFT="-2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1332336178117" HGAP="26" ID="ID_514809020" MODIFIED="1412162367376" TEXT="M&#xe9;todos" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1332336193969" HGAP="27" ID="ID_1992406345" MODIFIED="1412162367376" TEXT="Tempos" VSHIFT="2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1332335955411" HGAP="21" ID="ID_12244319" MODIFIED="1412162367376" TEXT="=f(ger&#xea;ncia)" VSHIFT="-3">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1332335988531" ID="ID_152470452" MODIFIED="1412162367376" TEXT="=f(experi&#xea;ncia)">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1332336003842" HGAP="21" ID="ID_738396652" MODIFIED="1412162367375" TEXT="=f(hist&#xf3;rico)" VSHIFT="4">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1332337010847" ID="ID_962821779" MODIFIED="1412162367375" TEXT="Lista de atividades" VSHIFT="8">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1332336064683" HGAP="23" ID="ID_1108526404" LINK="Figura_6-2.jpg" MODIFIED="1412162367375" TEXT="Template de atividade" VSHIFT="-14">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1332336865271" HGAP="22" ID="ID_395495113" MODIFIED="1412162367374" TEXT="Lista de atributos" VSHIFT="4">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1332336876870" HGAP="21" ID="ID_901194074" MODIFIED="1412162367374" TEXT="Premissas" VSHIFT="2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1332336890055" ID="ID_941105102" MODIFIED="1412162367373" TEXT="Restri&#xe7;&#xf5;es" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1332336901867" ID="ID_1740293334" MODIFIED="1412162367373" TEXT="Pessoal respons&#xe1;vel">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1332336915671" ID="ID_1593687210" MODIFIED="1412162367373" TEXT="Local" VSHIFT="-2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1332336929364" ID="ID_437699817" MODIFIED="1412162367373" TEXT="Ref. WBS">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1332336970899" HGAP="22" ID="ID_1489933432" MODIFIED="1412162367372" TEXT="Lista de milestones" VSHIFT="7">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
</node>
</node>
</map>
