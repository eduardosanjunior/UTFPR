<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#000000" CREATED="1336499721679" ID="ID_573518368" LINK="Figura_9-0.jpg" MODIFIED="1411582546135" TEXT="Recursos Humanos">
<font NAME="Handwriting - Dakota" SIZE="20"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties"/>
<node COLOR="#0033ff" CREATED="1336500192857" FOLDED="true" HGAP="-80" ID="ID_414334849" LINK="Figura_9-1.jpg" MODIFIED="1411582546125" POSITION="right" TEXT="Processos" VSHIFT="-111">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1336500225618" FOLDED="true" HGAP="18" ID="ID_170132057" MODIFIED="1411582546126" TEXT="Desenvolver o plano de recursos humanos" VSHIFT="-4">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1336500355468" HGAP="19" ID="ID_438734294" MODIFIED="1411582546126" TEXT="Fun&#xe7;&#xf5;es" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336500372892" ID="ID_595173621" MODIFIED="1411582546126" TEXT="Responsabilidades">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336500391298" HGAP="19" ID="ID_1983597419" MODIFIED="1411582546126" TEXT="Habilidades necess&#xe1;rias" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336500402334" ID="ID_1488393668" MODIFIED="1411582546126" TEXT="Rela&#xe7;&#xf5;es hier&#xe1;rquicas" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336500422742" ID="ID_1667465775" MODIFIED="1411582546126" TEXT="Plano de gerenciamento de pessoal" VSHIFT="3">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1336500244980" HGAP="18" ID="ID_1547476318" MODIFIED="1411582546126" TEXT="Mobilizar (formar) a equipe de projeto" VSHIFT="-3">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1336500266860" FOLDED="true" HGAP="17" ID="ID_258572878" MODIFIED="1411582546127" TEXT="Desenvolver a equipe de projeto" VSHIFT="1">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1336500481410" HGAP="19" ID="ID_1523140721" MODIFIED="1411582546127" TEXT="Compet&#xea;ncias">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336500493346" ID="ID_1539302548" MODIFIED="1411582546127" TEXT="Intera&#xe7;&#xe3;o com ambiente">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1336500284152" FOLDED="true" HGAP="16" ID="ID_1008690000" MODIFIED="1411582546127" TEXT="Gerenciar a equipe de projeto" VSHIFT="4">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1336500514790" ID="ID_1590809315" MODIFIED="1411582546127" TEXT="Acompanhar desempenho" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336500529606" ID="ID_1016962657" MODIFIED="1411582546127" TEXT="Feedback">
<font ITALIC="true" NAME="SansSerif" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336500547348" ID="ID_934146028" MODIFIED="1411582546127" TEXT="Resolu&#xe7;&#xe3;o de conflitos">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336500566786" ID="ID_261986119" MODIFIED="1411582546127" TEXT="Gerenciamento de mudan&#xe7;as para otimiza&#xe7;&#xe3;o de desempenho">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1336500650477" FOLDED="true" HGAP="67" ID="ID_851172882" MODIFIED="1411582546128" POSITION="right" TEXT="Quem faz o qu&#xea;?" VSHIFT="7">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1336500663582" HGAP="18" ID="ID_904412871" LINK="Figura_9-2.jpg" MODIFIED="1411582546128" TEXT="Matriz de responsabilidades" VSHIFT="-1">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1336500851471" FOLDED="true" ID="ID_213941577" MODIFIED="1411582546128" TEXT="Atribui&#xe7;&#xf5;es de cada profissional (Quem vai ...)">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1336500916203" HGAP="21" ID="ID_850845523" MODIFIED="1411582546128" TEXT="desenvolver e controlar a programa&#xe7;&#xe3;o?" VSHIFT="6">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336500961777" HGAP="42" ID="ID_206263153" MODIFIED="1411582546128" TEXT="acompanhar o or&#xe7;amento e desembolso?" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336501005764" HGAP="55" ID="ID_200359738" MODIFIED="1411582546128" TEXT="marcar as reuni&#xf5;es?" VSHIFT="2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336501014145" HGAP="68" ID="ID_473287954" MODIFIED="1411582546129" TEXT="apresentar os resultados do projeto aos interessados?" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336501031775" HGAP="80" ID="ID_964260189" MODIFIED="1411582546129" TEXT="buscar o comprometimento das equipes?" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336501045083" HGAP="89" ID="ID_1864124775" MODIFIED="1411582546129" TEXT="avaliar tecnicamente os produtos do projeto?" VSHIFT="-4">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336501060520" HGAP="93" ID="ID_1450189436" MODIFIED="1411582546129" TEXT="verificar as necessidades de mudan&#xe7;as?" VSHIFT="-7">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336501071712" HGAP="88" ID="ID_1677602478" MODIFIED="1411582546129" TEXT="acompanhar os riscos do projeto?" VSHIFT="-5">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336501089633" HGAP="84" ID="ID_1469020155" MODIFIED="1411582546129" TEXT="buscar novos recursos?" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336501099556" HGAP="68" ID="ID_1119550697" MODIFIED="1411582546129" TEXT="treinar conforme necessidades do projeto?" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336501112899" HGAP="59" ID="ID_1286730652" MODIFIED="1411582546129" TEXT="acompanhar as licita&#xe7;&#xf5;es e administrar os contratos?" VSHIFT="-32">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1336501292405" FOLDED="true" HGAP="21" ID="ID_1823910550" MODIFIED="1411582546129" TEXT="Sele&#xe7;&#xe3;o de recursos" VSHIFT="2">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1336501310699" FOLDED="true" HGAP="21" ID="ID_1345554943" MODIFIED="1411582546129" TEXT="Natureza do cargo" VSHIFT="-2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1336501334919" ID="ID_1615047052" MODIFIED="1411582546130" TEXT="Responsabilidades esperadas" VSHIFT="11"/>
<node COLOR="#111111" CREATED="1336501348927" HGAP="21" ID="ID_1490194077" MODIFIED="1411582546130" TEXT="Prop&#xf3;sitos" VSHIFT="-1"/>
<node COLOR="#111111" CREATED="1336501357554" ID="ID_29196166" MODIFIED="1411582546130" TEXT="Limites e extens&#xe3;o de autoridade" VSHIFT="-1"/>
<node COLOR="#111111" CREATED="1336501373980" HGAP="19" ID="ID_81066607" MODIFIED="1411582546130" TEXT="Contribui&#xe7;&#xe3;o esperada" VSHIFT="-1"/>
<node COLOR="#111111" CREATED="1336501386378" ID="ID_605074131" MODIFIED="1411582546130" TEXT="Dificuldades a enfrentar"/>
<node COLOR="#111111" CREATED="1336501397263" ID="ID_359711838" MODIFIED="1411582546130" TEXT="Treinamento e apoio poss&#xed;vel" VSHIFT="2"/>
</node>
<node COLOR="#990000" CREATED="1336501318674" FOLDED="true" ID="ID_711477478" MODIFIED="1411582546130" TEXT="Compet&#xea;ncias">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1336501441267" HGAP="23" ID="ID_999022336" MODIFIED="1411582546130" TEXT="Espec&#xed;ficas do cargo" VSHIFT="3"/>
<node COLOR="#111111" CREATED="1336501450987" FOLDED="true" HGAP="22" ID="ID_1712726631" MODIFIED="1411582546130" TEXT="Gen&#xe9;ricas" VSHIFT="-6">
<node COLOR="#111111" CREATED="1336501473634" HGAP="22" ID="ID_363335087" MODIFIED="1411582546130" TEXT="L&#xed;ngua estrangeira" VSHIFT="1"/>
<node COLOR="#111111" CREATED="1336501489947" ID="ID_1374556728" MODIFIED="1411582546130" TEXT="Atitudes e comportamento"/>
<node COLOR="#111111" CREATED="1336501499676" ID="ID_825376438" MODIFIED="1411582546130" TEXT="Estilo de lideran&#xe7;a" VSHIFT="1"/>
<node COLOR="#111111" CREATED="1336501514504" ID="ID_1463626159" MODIFIED="1411582546130" TEXT="Comunica&#xe7;&#xe3;o interpessoal" VSHIFT="1"/>
<node COLOR="#111111" CREATED="1336501527015" HGAP="22" ID="ID_1963652741" MODIFIED="1411582546130" TEXT="Atributos pessoais" VSHIFT="2"/>
</node>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1336501243178" FOLDED="true" HGAP="-82" ID="ID_741592437" MODIFIED="1411582546131" POSITION="right" TEXT="Forma&#xe7;&#xe3;o da equipe" VSHIFT="103">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1336501630617" ID="ID_478020756" MODIFIED="1411582546131" TEXT="Desafio: montar aloca&#xe7;&#xe3;o balanceada" VSHIFT="-1">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1336501733532" ID="ID_1679694436" LINK="Grafico_9-1.jpg" MODIFIED="1411582546131" TEXT="Histograma de recursos">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1336502392113" ID="ID_916426019" LINK="Grafico_9-2.jpg" MODIFIED="1411582546132" TEXT="Nivelamento de recursos" VSHIFT="3">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1336503142604" FOLDED="true" HGAP="55" ID="ID_1265388135" MODIFIED="1411582546132" POSITION="left" TEXT="Aspectos comportamentais e amadurecimento" VSHIFT="26">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1336503252630" FOLDED="true" ID="ID_900999452" MODIFIED="1411582546132" TEXT="Teorias motivacionais" VSHIFT="2">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1336503265220" HGAP="25" ID="ID_1822069462" MODIFIED="1411582546132" TEXT="Teoria X: ser humano evita o trabalho" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336503307160" FOLDED="true" ID="ID_1519111724" MODIFIED="1411582546132" TEXT="Teoria Y">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1336503364793" HGAP="19" ID="ID_620110142" MODIFIED="1411582546132" TEXT="&#xca;nfase ao ser humano"/>
<node COLOR="#111111" CREATED="1336503385022" ID="ID_1021341341" MODIFIED="1411582546132" TEXT="Organiza&#xe7;&#xe3;o dos elementos produtivos das empresas"/>
<node COLOR="#111111" CREATED="1336503404518" ID="ID_1000492316" MODIFIED="1411582546132" TEXT="Pessoas n&#xe3;o s&#xe3;o passivas"/>
<node COLOR="#111111" CREATED="1336503415261" ID="ID_1001101938" MODIFIED="1411582546132" TEXT="Pessoas t&#xea;m necessidades frente &#xe0;s organiza&#xe7;&#xf5;es"/>
<node COLOR="#111111" CREATED="1336503433510" ID="ID_1079419027" MODIFIED="1411582546133" TEXT="H&#xe1; fatores motivacionais e de desenvolvimento pessoal"/>
<node COLOR="#111111" CREATED="1336503470489" ID="ID_1922982152" MODIFIED="1411582546133" TEXT="Objetivos organizacionais mostram o caminho para que as pessoas produzam melhor"/>
</node>
<node COLOR="#990000" CREATED="1336503568285" HGAP="23" ID="ID_798870377" LINK="Figura_9-3.jpg" MODIFIED="1411582546133" TEXT="Teoria das Necessidades (Pir&#xe2;mide de Maslow)" VSHIFT="5">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336503854724" FOLDED="true" ID="ID_1121680559" MODIFIED="1411582546133" TEXT="Teoria de Herzberg">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1336503877123" ID="ID_436924666" MODIFIED="1411582546133" TEXT="Fatores higi&#xea;nicos (ambiente de trabalho)" VSHIFT="-2"/>
<node COLOR="#111111" CREATED="1336503910444" ID="ID_167043987" MODIFIED="1411582546133" TEXT="Fatores motivacionais (trabalho em si)"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1336504050329" FOLDED="true" ID="ID_863517070" MODIFIED="1411582546133" TEXT="Lideran&#xe7;a">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1336504078420" FOLDED="true" HGAP="22" ID="ID_20154527" MODIFIED="1411582546133" TEXT="Teoria da Lideran&#xe7;a Situacional" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1336504164123" HGAP="24" ID="ID_738300947" MODIFIED="1411582546133" TEXT="Fatores considerados" VSHIFT="-14">
<node COLOR="#111111" CREATED="1336504105128" ID="ID_1906565147" MODIFIED="1411582546133" TEXT="Quantidade de orienta&#xe7;&#xe3;o e dire&#xe7;&#xe3;o (tarefas)" VSHIFT="3"/>
<node COLOR="#111111" CREATED="1336504126120" ID="ID_492579581" MODIFIED="1411582546133" TEXT="Quantidade de apoio socioemocional (relacionamentos)"/>
<node COLOR="#111111" CREATED="1336504143546" ID="ID_1641694990" MODIFIED="1411582546133" TEXT="N&#xed;vel de prontid&#xe3;o (maturidade)" VSHIFT="-2"/>
</node>
<node COLOR="#111111" CREATED="1336504912152" ID="ID_456022366" MODIFIED="1411582546134" TEXT="Formas de exercer lideran&#xe7;a">
<node COLOR="#111111" CREATED="1336504928363" HGAP="22" ID="ID_1566169582" MODIFIED="1411582546134" TEXT="Determinar"/>
<node COLOR="#111111" CREATED="1336504940715" ID="ID_1165641949" MODIFIED="1411582546134" TEXT="Persuadir"/>
<node COLOR="#111111" CREATED="1336504947230" ID="ID_1621929765" MODIFIED="1411582546134" TEXT="Compartilhar"/>
<node COLOR="#111111" CREATED="1336504957635" HGAP="21" ID="ID_1864531763" MODIFIED="1411582546134" TEXT="Delegar"/>
</node>
</node>
<node COLOR="#990000" CREATED="1336505158169" FOLDED="true" ID="ID_104808828" MODIFIED="1411582546134" TEXT="Teoria de Burns (Lideran&#xe7;a Transformacional)">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1336505244130" ID="ID_485129402" MODIFIED="1411582546134" TEXT="N&#xed;veis altos de moralidade e motiva&#xe7;&#xe3;o" VSHIFT="-2"/>
<node COLOR="#111111" CREATED="1336505262322" ID="ID_1996664198" MODIFIED="1411582546134" TEXT="Conscientiza&#xe7;&#xe3;o sobre import&#xe2;ncia e valor dos resultados do trabalho"/>
<node COLOR="#111111" CREATED="1336505397414" FOLDED="true" ID="ID_845074171" MODIFIED="1411582546134" TEXT="Programas de atividades">
<node COLOR="#111111" CREATED="1336505434470" HGAP="21" ID="ID_1343481802" MODIFIED="1411582546134" TEXT="Cria&#xe7;&#xe3;o de vis&#xe3;o" VSHIFT="2"/>
<node COLOR="#111111" CREATED="1336505450603" HGAP="21" ID="ID_1338107942" MODIFIED="1411582546134" TEXT="Mobiliza&#xe7;&#xe3;o de grupos"/>
<node COLOR="#111111" CREATED="1336505461144" ID="ID_1986769651" MODIFIED="1411582546134" TEXT="Institucionaliza&#xe7;&#xe3;o da mudan&#xe7;a"/>
</node>
</node>
<node COLOR="#990000" CREATED="1336505507055" FOLDED="true" ID="ID_576805270" MODIFIED="1411582546134" TEXT="Lideran&#xe7;a Carism&#xe1;tica">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1336505517675" HGAP="22" ID="ID_1459001035" MODIFIED="1411582546135" TEXT="carisma = resultado das percep&#xe7;&#xf5;es dos seguidores sobre as qualidades dos l&#xed;deres" VSHIFT="-12"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1336505845300" FOLDED="true" ID="ID_1779035392" MODIFIED="1411582546135" TEXT="Habilidades determinantes de sucesso">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1336505870996" HGAP="23" ID="ID_554489030" MODIFIED="1411582546135" TEXT="Lideran&#xe7;a">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336505887916" ID="ID_1590147722" MODIFIED="1411582546135" TEXT="Relacionamento Humano (gest&#xe3;o de conflitos)" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1336505916851" FOLDED="true" ID="ID_1164006692" MODIFIED="1411582546135" TEXT="Negocia&#xe7;&#xe3;o">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1336505957602" ID="ID_421678526" MODIFIED="1411582546135" TEXT="Separar as pessoas dos problemas" VSHIFT="4"/>
<node COLOR="#111111" CREATED="1336505976746" HGAP="19" ID="ID_773980841" MODIFIED="1411582546135" TEXT="Concentrar nos interesses e n&#xe3;o nas posi&#xe7;&#xf5;es"/>
<node COLOR="#111111" CREATED="1336506019137" ID="ID_1757353932" MODIFIED="1411582546135" TEXT="Criar op&#xe7;&#xf5;es de ganhos m&#xfa;ltiplos"/>
<node COLOR="#111111" CREATED="1336506043786" ID="ID_820038448" MODIFIED="1411582546135" TEXT="Insistir em crit&#xe9;rios objetivos"/>
</node>
</node>
</node>
</node>
</map>
