<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#000000" CREATED="1348688965511" ID="ID_180484831" LINK="Figura_12_0.jpg" MODIFIED="1411582649888" TEXT="Aquisi&#xe7;&#xf5;es">
<font NAME="Handwriting - Dakota" SIZE="20"/>
<hook NAME="accessories/plugins/AutomaticLayout.properties"/>
<node COLOR="#0033ff" CREATED="1348689076081" FOLDED="true" HGAP="34" ID="ID_1235564803" MODIFIED="1411582649876" POSITION="right" TEXT="Motiva&#xe7;&#xe3;o" VSHIFT="-41">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1348689090692" HGAP="18" ID="ID_420662269" MODIFIED="1411582649876" TEXT="Necessidade de compet&#xea;ncias espec&#xed;ficas" VSHIFT="-3">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1348689118015" ID="ID_598841510" MODIFIED="1411582649876" TEXT="Mais interessante comprar do que fazer (make or buy)">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1348689245934" FOLDED="true" HGAP="31" ID="ID_479466314" LINK="Figura_12_1.jpg" MODIFIED="1411582649877" POSITION="right" TEXT="Processos" VSHIFT="-42">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1348689256573" HGAP="24" ID="ID_1347011873" MODIFIED="1411582649877" TEXT="Planejar as aquisi&#xe7;&#xf5;es" VSHIFT="5">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1348689268806" HGAP="25" ID="ID_1888231496" MODIFIED="1411582649877" TEXT="Realizar as aquisi&#xe7;&#xf5;es" VSHIFT="-24">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348689286485" HGAP="21" ID="ID_297447006" MODIFIED="1411582649877" TEXT="Planejar a solicita&#xe7;&#xe3;o">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348689301665" ID="ID_221225448" MODIFIED="1411582649877" TEXT="Solicitar">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348689308725" ID="ID_873666176" MODIFIED="1411582649877" TEXT="Selecionar as fontes">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1348689326300" HGAP="26" ID="ID_398846299" MODIFIED="1411582649878" TEXT="Gerenciar as aquisi&#xe7;&#xf5;es" VSHIFT="-3">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
<node COLOR="#00b439" CREATED="1348689336275" HGAP="25" ID="ID_1451813508" MODIFIED="1411582649878" TEXT="Encerrar as aquisi&#xe7;&#xf5;es" VSHIFT="10">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
</node>
</node>
<node COLOR="#0033ff" CREATED="1348689734006" FOLDED="true" HGAP="41" ID="ID_454308150" MODIFIED="1411582649878" POSITION="right" TEXT="Modelos de sociedade" VSHIFT="23">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1348689760545" HGAP="19" ID="ID_1511333498" MODIFIED="1411582649878" TEXT="Atividade" VSHIFT="-5">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348690023175" HGAP="21" ID="ID_641155330" MODIFIED="1411582649878" TEXT="Civil" VSHIFT="-19">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1348689837549" HGAP="18" ID="ID_188281901" MODIFIED="1411582649878" TEXT="Com&#xe9;rcio" VSHIFT="4">
<node COLOR="#111111" CREATED="1348689891569" HGAP="17" ID="ID_292032971" MODIFIED="1411582649878" TEXT="ICMS" VSHIFT="-10"/>
</node>
<node COLOR="#111111" CREATED="1348689848772" ID="ID_848239838" MODIFIED="1411582649879" TEXT="Ind&#xfa;stria">
<node COLOR="#111111" CREATED="1348689901904" HGAP="19" ID="ID_1875426696" MODIFIED="1411582649879" TEXT="IPI" VSHIFT="-10"/>
</node>
<node COLOR="#111111" CREATED="1348689854799" ID="ID_1893589297" MODIFIED="1411582649879" TEXT="Servi&#xe7;os">
<node COLOR="#111111" CREATED="1348689884404" HGAP="24" ID="ID_721465756" MODIFIED="1411582649879" TEXT="ISS" VSHIFT="-8"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1348689983737" ID="ID_987413269" MODIFIED="1411582649879" TEXT="Composi&#xe7;&#xe3;o">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348689788095" HGAP="28" ID="ID_1620407241" MODIFIED="1411582649879" TEXT="Por quotas" VSHIFT="-2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1348690042673" HGAP="18" ID="ID_1232463939" MODIFIED="1411582649879" TEXT="Limitada" VSHIFT="-11"/>
</node>
<node COLOR="#990000" CREATED="1348689936946" HGAP="30" ID="ID_1358355767" MODIFIED="1411582649879" TEXT="Por a&#xe7;&#xf5;es" VSHIFT="2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1348689709337" FOLDED="true" HGAP="48" ID="ID_1747513133" LINK="Figura_12_3.jpg" MODIFIED="1411582649880" POSITION="right" TEXT="Tipos de contrato" VSHIFT="45">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1348690143325" FOLDED="true" HGAP="24" ID="ID_1058942444" MODIFIED="1411582649880" TEXT="PMI" VSHIFT="-4">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348690075764" HGAP="22" ID="ID_900867611" MODIFIED="1411582649880" TEXT="Pre&#xe7;o fixo ou fechado" VSHIFT="-2">
<arrowlink DESTINATION="ID_433190831" ENDARROW="Default" ENDINCLINATION="148;0;" ID="Arrow_ID_128497033" STARTARROW="None" STARTINCLINATION="148;0;"/>
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348690111953" ID="ID_622132817" MODIFIED="1411582649880" TEXT="Custos reembols&#xe1;veis" VSHIFT="-2">
<arrowlink DESTINATION="ID_963569890" ENDARROW="Default" ENDINCLINATION="55;0;" ID="Arrow_ID_1330034988" STARTARROW="None" STARTINCLINATION="55;0;"/>
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348690129180" ID="ID_264429488" MODIFIED="1411582649881" TEXT="Tempo e material">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1348691392808" HGAP="23" ID="ID_1675114552" MODIFIED="1411582649881" TEXT="H&#xed;brido: valor total n&#xe3;o definido inicialmente, mas com disposi&#xe7;&#xf5;es contratuais de pre&#xe7;o fixo (taxas unit&#xe1;rias pr&#xe9;-fixadas)" VSHIFT="-21"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1348690194074" FOLDED="true" ID="ID_457294490" MODIFIED="1411582649881" TEXT="C&#xf3;digo Civil">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348690208655" HGAP="21" ID="ID_963569890" MODIFIED="1411582649881" TEXT="Por administra&#xe7;&#xe3;o" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1348691110496" HGAP="24" ID="ID_1256957597" MODIFIED="1411582649881" TEXT="Remunera&#xe7;&#xe3;o = custos (MO + material) + taxa de administra&#xe7;&#xe3;o" VSHIFT="-17"/>
</node>
<node COLOR="#990000" CREATED="1348690224161" ID="ID_1008200536" MODIFIED="1411582649881" TEXT="Por pre&#xe7;o unit&#xe1;rio">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1348691208988" HGAP="27" ID="ID_142130852" MODIFIED="1411582649881" TEXT="Informa&#xe7;&#xf5;es do projeto ainda n&#xe3;o claras" VSHIFT="-8"/>
</node>
<node COLOR="#990000" CREATED="1348690239747" ID="ID_433190831" MODIFIED="1411582649881" TEXT="Por pre&#xe7;o fixo">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1348691334177" HGAP="22" ID="ID_1043322283" MODIFIED="1411582649881" TEXT="Fornecimento completo (bem/servi&#xe7;o), prazo determinado" VSHIFT="-12"/>
</node>
<node COLOR="#990000" CREATED="1348690251918" ID="ID_913084260" MODIFIED="1411582649881" TEXT="Turnkey">
<font ITALIC="true" NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1348691795715" HGAP="18" ID="ID_295372197" MODIFIED="1411582649881" TEXT="Pr&#xea;mio por gest&#xe3;o de riscos para cliente" VSHIFT="-5"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1348690272743" HGAP="24" ID="ID_125965288" MODIFIED="1411582649881" TEXT="Outros">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348690281104" FOLDED="true" HGAP="21" ID="ID_1498333322" MODIFIED="1411582649881" TEXT="Compensa&#xe7;&#xe3;o por BDI" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1348691674207" HGAP="21" ID="ID_1588909261" MODIFIED="1411582649882" TEXT="Bonifica&#xe7;&#xe3;o por despesas indiretas" VSHIFT="-2"/>
<node COLOR="#111111" CREATED="1348691719735" HGAP="21" ID="ID_1040388629" MODIFIED="1411582649882" TEXT="Prote&#xe7;&#xe3;o contra intemp&#xe9;ries econ&#xf4;micas" VSHIFT="-1"/>
</node>
<node COLOR="#990000" CREATED="1348690359508" FOLDED="true" ID="ID_280081167" MODIFIED="1411582649882" TEXT="Empreitada global">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1348690495509" HGAP="19" ID="ID_449266765" MODIFIED="1411582649882" TEXT="Fornecedor apresenta pre&#xe7;o global"/>
<node COLOR="#111111" CREATED="1348690519602" ID="ID_501294250" MODIFIED="1411582649882" TEXT="Riscos sobre fornecedor"/>
</node>
<node COLOR="#990000" CREATED="1348690369667" FOLDED="true" ID="ID_156099233" MODIFIED="1411582649882" TEXT="EPC (Engineering, Procurement and Construction)">
<font ITALIC="true" NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1348690617734" HGAP="21" ID="ID_390723543" MODIFIED="1411582649882" TEXT="Semelhante &#xe0; Empreitada Global" VSHIFT="-2"/>
<node COLOR="#111111" CREATED="1348690632326" ID="ID_608788468" MODIFIED="1411582649882" TEXT="Defini&#xe7;&#xe3;o de tipos de tecnologia, qualidade, etc."/>
<node COLOR="#111111" CREATED="1348690709165" ID="ID_306669516" MODIFIED="1411582649882" TEXT="Multas por atraso ou n&#xe3;o cumprimento de especifica&#xe7;&#xf5;es" VSHIFT="3"/>
<node COLOR="#111111" CREATED="1348690757750" HGAP="19" ID="ID_798177947" MODIFIED="1411582649882" TEXT="Variante EPCM" VSHIFT="6">
<node COLOR="#111111" CREATED="1348690784946" HGAP="18" ID="ID_1934389371" MODIFIED="1411582649882" TEXT="Compras em nome do cliente" VSHIFT="-9"/>
</node>
<node COLOR="#111111" CREATED="1348690950359" ID="ID_1021703725" MODIFIED="1411582649882" TEXT="Superestimativas (EPC) vs. Pre&#xe7;os/condi&#xe7;&#xf5;es contratuais (cliente)"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1348776845107" FOLDED="true" HGAP="47" ID="ID_1293439682" MODIFIED="1411582649883" POSITION="left" TEXT="Sele&#xe7;&#xe3;o e administra&#xe7;&#xe3;o de contratos" VSHIFT="-85">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1348777390769" FOLDED="true" ID="ID_525703932" MODIFIED="1411582649883" TEXT="Sele&#xe7;&#xe3;o">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348777068511" HGAP="19" ID="ID_1223803110" MODIFIED="1411582649883" TEXT="Pr&#xe9;-qualifica&#xe7;&#xe3;o">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1348777085892" HGAP="19" ID="ID_367781931" MODIFIED="1411582649883" TEXT="An&#xe1;lise de hist&#xf3;rico de fornecimentos" VSHIFT="1"/>
<node COLOR="#111111" CREATED="1348777119373" ID="ID_185641703" MODIFIED="1411582649883" TEXT="Atestado de capacidade t&#xe9;cnica"/>
<node COLOR="#111111" CREATED="1348777135415" ID="ID_1178602163" MODIFIED="1411582649883" TEXT="Recursos dispon&#xed;veis" VSHIFT="1"/>
<node COLOR="#111111" CREATED="1348777161335" ID="ID_597523210" MODIFIED="1411582649883" TEXT="Dados financeiros/cont&#xe1;beis"/>
<node COLOR="#111111" CREATED="1348777175701" ID="ID_636154210" MODIFIED="1411582649883" TEXT="Certid&#xf5;es jur&#xed;dico-financeiras" VSHIFT="-5"/>
</node>
<node COLOR="#990000" CREATED="1348777225832" HGAP="19" ID="ID_589558183" MODIFIED="1411582649883" TEXT="Visita e busca de evid&#xea;ncias">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348777656417" ID="ID_3717177" MODIFIED="1411582649883" TEXT="Envio/recebimento de propostas">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1348777455535" HGAP="19" ID="ID_983790917" MODIFIED="1411582649883" TEXT="Contrata&#xe7;&#xe3;o">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348777495260" HGAP="19" ID="ID_432530353" MODIFIED="1411582649884" TEXT="Avalia&#xe7;&#xe3;o de propostas" VSHIFT="-18">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1348777524949" HGAP="19" ID="ID_1623176978" MODIFIED="1411582649884" TEXT="Crit&#xe9;rios pr&#xe9;-estabelecidos" VSHIFT="-1"/>
<node COLOR="#111111" CREATED="1348777548214" ID="ID_543558269" MODIFIED="1411582649884" TEXT="T&#xe9;cnicas de sele&#xe7;&#xe3;o multicrit&#xe9;rios">
<node COLOR="#111111" CREATED="1348777703442" HGAP="18" ID="ID_863756945" LINK="8.%20AHP_jsf.pdf" MODIFIED="1411582649884" TEXT="Analytical Hierarchic Process (AHP)" VSHIFT="-18">
<font ITALIC="true" NAME="SansSerif" SIZE="12"/>
<node COLOR="#111111" CREATED="1348837000504" ID="ID_1687179103" MODIFIED="1411582649884" TEXT="Decomposi&#xe7;&#xe3;o do problema"/>
<node COLOR="#111111" CREATED="1348837014498" ID="ID_1259697659" LINK="Saaty.jpeg" MODIFIED="1411582649884" TEXT="Compara&#xe7;&#xe3;o de elementos"/>
<node COLOR="#111111" CREATED="1348837030642" ID="ID_330362528" MODIFIED="1411582649884" TEXT="S&#xed;ntese de prioridades"/>
<node COLOR="#111111" CREATED="1348836854635" ID="ID_1219116102" LINK="AHPcalc_vers_22.5.12/AHPcalc%20version%2022.5.12.xlsx" MODIFIED="1411582649884" TEXT="Template em Excel"/>
</node>
</node>
<node COLOR="#111111" CREATED="1348776946482" ID="ID_1014367851" MODIFIED="1411582649884" TEXT="Negocia&#xe7;&#xe3;o" VSHIFT="9">
<node COLOR="#111111" CREATED="1348776984169" HGAP="18" ID="ID_1586381998" MODIFIED="1411582649884" TEXT="Escopo do contrato" VSHIFT="1"/>
<node COLOR="#111111" CREATED="1348777596904" ID="ID_119270881" MODIFIED="1411582649884" TEXT="Investimento"/>
<node COLOR="#111111" CREATED="1348777005713" ID="ID_523963154" MODIFIED="1411582649884" TEXT="Regras e penalidades" VSHIFT="-2"/>
<node COLOR="#111111" CREATED="1348777615297" ID="ID_375623192" MODIFIED="1411582649884" TEXT="Condi&#xe7;&#xf5;es e garantias"/>
</node>
</node>
</node>
<node COLOR="#00b439" CREATED="1348837127055" FOLDED="true" ID="ID_501598021" MODIFIED="1411582649884" TEXT="Encerramento">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348837142896" HGAP="23" ID="ID_48221074" MODIFIED="1411582649884" TEXT="Supervis&#xe3;o de instala&#xe7;&#xe3;o (bens)" VSHIFT="5">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348837164350" HGAP="21" ID="ID_414261991" MODIFIED="1411582649885" TEXT="Desmobiliza&#xe7;&#xe3;o (servi&#xe7;os)" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348837179289" ID="ID_553887076" MODIFIED="1411582649885" TEXT="Entrega final dos bens e servi&#xe7;os">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348837189977" ID="ID_1798074846" MODIFIED="1411582649885" TEXT="Entrega dos documentos t&#xe9;cnicos e fiscais">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348837202757" ID="ID_1356868026" MODIFIED="1411582649885" TEXT="Acerto de todas as pend&#xea;ncias">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348837216720" ID="ID_807587375" MODIFIED="1411582649885" TEXT="Valida&#xe7;&#xe3;o das garantias e in&#xed;cio do prazo de garantia">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348837234808" ID="ID_424800131" MODIFIED="1411582649885" TEXT="Quita&#xe7;&#xe3;o de res&#xed;duos financeiros">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348837249163" ID="ID_1558529033" MODIFIED="1411582649885" TEXT="Emiss&#xe3;o do termo de Recebimento/Aceita&#xe7;&#xe3;o">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348837265082" ID="ID_927874912" MODIFIED="1411582649885" TEXT="Arquivamento da documenta&#xe7;&#xe3;o gerada no contrato">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1348691966837" FOLDED="true" HGAP="48" ID="ID_1377695716" MODIFIED="1411582649886" POSITION="left" TEXT="Planejamento de aquisi&#xe7;&#xf5;es" VSHIFT="53">
<edge STYLE="sharp_bezier" WIDTH="8"/>
<font NAME="Handwriting - Dakota" SIZE="18"/>
<node COLOR="#00b439" CREATED="1348767569034" FOLDED="true" HGAP="21" ID="ID_557784910" MODIFIED="1411582649886" TEXT="Make or buy?" VSHIFT="-11">
<edge STYLE="bezier" WIDTH="thin"/>
<font ITALIC="true" NAME="SansSerif" SIZE="16"/>
<node COLOR="#990000" CREATED="1348767614336" HGAP="19" ID="ID_169616650" MODIFIED="1411582649886" TEXT="An&#xe1;lise de conjuntura externa" VSHIFT="-2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348767628309" ID="ID_1800707609" MODIFIED="1411582649886" TEXT="An&#xe1;lise de conjuntura interna">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1348768605400" FOLDED="true" ID="ID_1043833712" MODIFIED="1411582649886" TEXT="Abordagem dos fornecedores">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348768642705" ID="ID_558671483" MODIFIED="1411582649886" TEXT="Potencial e possibilidades">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348768655305" ID="ID_848697313" MODIFIED="1411582649886" TEXT="Compet&#xea;ncias">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348768665418" ID="ID_138718581" MODIFIED="1411582649886" TEXT="Hist&#xf3;rico, antecedentes">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
<node COLOR="#990000" CREATED="1348768691666" ID="ID_317395243" MODIFIED="1411582649886" TEXT="Contatos" VSHIFT="2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1348768717834" FOLDED="true" HGAP="21" ID="ID_1422323261" MODIFIED="1411582649887" TEXT="Licita&#xe7;&#xf5;es" VSHIFT="10">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348768734337" HGAP="24" ID="ID_1194560840" MODIFIED="1411582649887" TEXT="Convite" VSHIFT="-1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1348768749828" HGAP="34" ID="ID_213714945" MODIFIED="1411582649887" TEXT="Valores/volumes menores" VSHIFT="-9"/>
</node>
<node COLOR="#990000" CREATED="1348776048412" HGAP="19" ID="ID_1378775972" MODIFIED="1411582649887" TEXT="Tomadas de pre&#xe7;o" VSHIFT="1">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1348776057209" HGAP="27" ID="ID_107776262" MODIFIED="1411582649887" TEXT="Valores/volumes m&#xe9;dios" VSHIFT="-7"/>
</node>
<node COLOR="#990000" CREATED="1348776075063" ID="ID_115859600" MODIFIED="1411582649887" TEXT="Concorr&#xea;ncias" VSHIFT="2">
<font NAME="Handwriting - Dakota" SIZE="14"/>
<node COLOR="#111111" CREATED="1348776085492" ID="ID_1762153443" MODIFIED="1411582649887" TEXT="Valores/volumes maiores" VSHIFT="-6"/>
</node>
</node>
<node COLOR="#00b439" CREATED="1348776129379" FOLDED="true" ID="ID_847415486" MODIFIED="1411582649887" TEXT="Documentos">
<edge STYLE="bezier" WIDTH="thin"/>
<font NAME="Handwriting - Dakota" SIZE="16"/>
<node COLOR="#990000" CREATED="1348776136298" HGAP="21" ID="ID_954584972" MODIFIED="1411582649887" TEXT="Request for Information (RFI)" VSHIFT="-1">
<font ITALIC="true" NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1348776180510" HGAP="19" ID="ID_473697343" MODIFIED="1411582649887" TEXT="Nome da empresa" VSHIFT="2"/>
<node COLOR="#111111" CREATED="1348776189881" ID="ID_1747632130" MODIFIED="1411582649887" TEXT="Endere&#xe7;o"/>
<node COLOR="#111111" CREATED="1348776195722" ID="ID_1343309162" MODIFIED="1411582649887" TEXT="Contato"/>
<node COLOR="#111111" CREATED="1348776200962" ID="ID_1282387254" MODIFIED="1411582649888" TEXT="Rela&#xe7;&#xe3;o dos S&#xf3;cios"/>
<node COLOR="#111111" CREATED="1348776209254" ID="ID_213777409" MODIFIED="1411582649888" TEXT="Capital"/>
<node COLOR="#111111" CREATED="1348776215149" ID="ID_438256283" MODIFIED="1411582649888" TEXT="Dados do balan&#xe7;o"/>
<node COLOR="#111111" CREATED="1348776223046" ID="ID_87046772" MODIFIED="1411582649888" TEXT="Refer&#xea;ncias"/>
<node COLOR="#111111" CREATED="1348776232305" ID="ID_1366380358" MODIFIED="1411582649888" TEXT="Condi&#xe7;&#xf5;es de entregas"/>
</node>
<node COLOR="#990000" CREATED="1348776155254" ID="ID_1569080184" MODIFIED="1411582649888" TEXT="Request for Proposal (RFP)">
<font ITALIC="true" NAME="SansSerif" SIZE="14"/>
<node COLOR="#111111" CREATED="1348776453346" HGAP="16" ID="ID_1375420221" MODIFIED="1411582649888" TEXT="Valor de investimento" VSHIFT="1"/>
<node COLOR="#111111" CREATED="1348776377858" HGAP="14" ID="ID_1041754112" MODIFIED="1411582649888" TEXT="Caracter&#xed;sticas do servi&#xe7;o ou produto" VSHIFT="-1"/>
<node COLOR="#111111" CREATED="1348776391301" HGAP="15" ID="ID_1804900231" MODIFIED="1411582649888" TEXT="Refer&#xea;ncias (clientes existentes, payback, etc.)"/>
<node COLOR="#111111" CREATED="1348776436527" HGAP="16" ID="ID_1096153901" MODIFIED="1411582649888" TEXT="Termos e condi&#xe7;&#xf5;es"/>
<node COLOR="#111111" CREATED="1348776756536" ID="ID_631736629" MODIFIED="1411582649888" TEXT="Padr&#xe3;o de RFP"/>
</node>
</node>
</node>
</node>
</map>
