# Template: 	AHPcalc
# Author:	Klaus Goepel
# Contact: 	http://bpmsg.com
# Version:	22.5.2012

# New from Version 7.4.2012 onwards

After receiving a lot of questions, how to do the calculation, when comparisons from
more than one participants have to be done, I implemented this feature in the Excel
template. In the current version max. 7 input sheets can be filled out (sheets input 1 - 7)
All matrixes are shown in a summary sheet multInp. There the geometric mean is calculated
for the consolidated input matrix of all participants.
The result is shown in the summary sheet. The next version planned will also allow to select
individual participants, to see the individual results.

With the update also the matrix calculation was simplified. I am using only one calculation
sheet 8x8 for all number of criteria (3-8). The "empty" elements are set to "1"

In addition to the above new multi input feature the excel sheet was converted to the newer
excel version MS excel 2010 with xlsx extension.

The input sheets are protected without password, to modify, just unprotect the sheets.

# How to use the template?
Steps:
1. Open the Excel file AHPcalc version dd.mm.yy.xls
2. Select the worksheet "Summary"
3. Input values in the green fields only
	a) number of criteria in "n=" (3-8)
	b) number of participants "N=" (1-7)
	c) objective (text)
	d) Author (text, optional)
	e) Date (date, optional)
	f) Criteria and Comments 1 to n in "Table"

4. Select worksheet "Input1"
5. Make your pair-wise comparisons for the criteria listed (green area)
6. for more the 1 comparison select worksheet "Input2"
7. Input the pair-wise comparisons for the criteria listed (green area)
8. Repeat 6. and 7. for the number of inputs (up to sheet Input7

9. Go back to sheet "Summary" to see the result:
Normalized principal Eigenvector (Weights), Eigenvalue and Consistency Ratio
10. Select participant number p (1-7) to see the individual results, select p=0 
to see the consolidated result

# Feedback and questions: http://bpmsg.com 
# Terms of use: see under terms & privacy on bpmsg.com

!!! Attention!!! 
This is a first version with the new functionality,please feedback in case of any bugs
or errors. Double check data and result carefully.

# License
This work is licensed under the Creative Commons Attribution-Noncommercial 3.0 Singapore License. 
To view a copy of this license, visit http://creativecommons.org/licenses/by-nc/3.0/sg/ 
or send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.

# Credits
I would appreciate feedback about the use of the template and your AHP application.
Please give credit to the author in case you use the template for a paper or work to be published.