% a06_01 [script]

clear all; close all; clc

% usa nlfilter para achar var local
% e fspecial para achar media local

gorig = imread('Lenna256g.png');
figure, imshow(gorig), title('Original')

% Insere ruido Gaussiano m = 0 e desvio padr�o = 10
g = imnoise(gorig,'gaussian',(0/255),(10/255)^2);
figure, imshow(gorig), title('Com ruido')

% Intera��o para selecionar regi�o do ruido
disp('Selecione uma regi�o para estimar a vari�ncia do ru�do (escura e homogenea).')
[reg, rect] = imcrop(g);
% rect = [xmin ymin width height]
imin = ceil(rect(2)); %linha cse
jmin = ceil(rect(1)); %coluna cse
imax = floor(rect(2)+rect(4)); %linha cid
jmax = floor(rect(1)+rect(3)); %coluna cid
disp('Coodenadas da regi�o selecionada')
disp(['Linha do canto superior esquerdo: ' num2str(imin)])
disp(['Coluna do canto superior esquerdo: ' num2str(jmin)])
disp(['Linha do canto inferior direito: ' num2str(imax)])
disp(['Coluna do canto inferior direito: ' num2str(jmax)])

g = double(g);

vnoise = var(double(reg(:))); %uma cte para o filtro (escalar)

nrcw = 5; % numero de linhas e colunas da janela

% Imagem com as vari�ncias locais
fun = @(x)var(x(:));
vlocal = nlfilter(g,[nrcw nrcw],fun);
figure, imshow(mat2gray(vlocal)), title('Vari�ncias')

% Imagem com as m�dias locais
h = fspecial('average', [nrcw nrcw]);
mlocal = imfilter(g, h, 0);
figure, imshow(uint8(mlocal)), title('M�dia 5x5');

% Filtro
out = (1 - (vnoise./vlocal)).*g + (vnoise./vlocal).*mlocal;
out = uint8(out);
figure, imshow(out), title('MMSE 5x5');

