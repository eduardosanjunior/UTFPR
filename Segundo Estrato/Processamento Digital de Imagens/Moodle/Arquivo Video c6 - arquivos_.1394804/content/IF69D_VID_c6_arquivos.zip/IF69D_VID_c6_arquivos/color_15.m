% color_15 [script]

clear all, close all, clc

%rgb = imread('allColors32.png');
rgb = imread('shark1.jpg');

% allColors32 � uma imagem RGB (8 bits/pixel) com todas as cores poss�veis
% como se estiv�ssemos usando 5 bits/pixel. N�mero de cores diferentes
% poss�veis: 2^15 = 32*32*32 = 32768.
[x1, map] = cmunique(rgb);
n_rgb = size(map, 1) %n�mero de cores em rgb
figure, imshow(rgb), title('rgb')

% Quantiza��o uniforme: o m�nimo poss�vel � quantizar cada canal em apenas
% dois valores. Isso d� 2*2*2 = 8.
levels = [255/2]; %2 niveis por canal = 8 cores
%values = [0 255]; 
values = [255*1/4 255*3/4]; %cor resultante � a do centro do cubo
r = rgb(:,:,1);
g = rgb(:,:,2);
b = rgb(:,:,3);
rq = imquantize(r, levels, values);
gq = imquantize(g, levels, values);
bq = imquantize(b, levels, values);
rq = uint8(rq);
gq = uint8(gq);
bq = uint8(bq);
rgb_q = cat(3, rq, gq, bq);
figure, imshow(rgb_q), title('x1 map1')
[x1, map1] = cmunique(rgb_q);
n_map1 = size(map1, 1)
pc = label2rgb(x1);

figure, scatter3(map1(:,1), map1(:,2), map1(:,3), 300, map1, 'filled')
title('map1')
xlim([0 1]), ylim([0 1]), zlim([0 1])
xlabel('R'), ylabel('G'), zlabel('B')