% color_16 [script]

clear all; close all; clc

%1) Fazer com allColors32 8 e 27 cores
%2) Fazer com shark1 8 cores e observar que a barriga do tubar�o foi pro
%   grupo de cores da �gua. O que d� pra fazer pra tentar concertar usando
%   quantiza��o uniforme? R: usar 27 cores.

% allColors32 � uma imagem RGB (8 bits/pixel) com todas as cores poss�veis
% como se estiv�ssemos usando 5 bits/pixel. N�mero de cores diferentes
% poss�veis: 2^15 = 32*32*32 = 32768.
% rgb = imread('allColors32.png');
% Observar que as dimens�es de rgb s�o 32*1024 = 32768 
 rgb = imread('shark1.jpg');

% S� pra ver quantas cores �nicas temos na imagem original
[x1, map] = cmunique(rgb);
n_map = size(map, 1) %n�mero de cores em rgb
figure, imshow(rgb), title('rgb')

##% Quantiza��o uniforme: o m�nimo poss�vel � quantizar cada canal em apenas
##% dois valores. Isso d� 2*2*2 = 8. Pr�xima: 3*3*3 = 27. Pr�xima: 4*4*4 = 64.
##levels = [255*1/2]; %2 niveis por canal = 8 cores
##values = [255*1/4 255*3/4]; %cor � a do centro do cubo quantizado

##levels = [255*1/3 255*2/3]; %3 niveis por canal = 27 cores
##values = [255*1/6 255*3/6 255*5/6]; %cor � do centro do cubo quantiz.

levels = [255*1/4 255*2/4 255*3/4]; %4 niveis por canal = 64 cores
values = [255*1/8 255*3/8 255*5/8 255*7/8]; %cor � do centro do cubo quantiz.

r = rgb(:,:,1);
g = rgb(:,:,2);
b = rgb(:,:,3);
rq = imquantize(r, levels, values);
gq = imquantize(g, levels, values);
bq = imquantize(b, levels, values);
rq = uint8(rq);
gq = uint8(gq);
bq = uint8(bq);
rgb_q = cat(3, rq, gq, bq);
figure, imshow(rgb_q), title('rgb\_q')
[x1, map1] = cmunique(rgb_q);
n_map1 = size(map1, 1)

% Os mapa de cores dado por 'values' pode levar a uma interpreta��o errada do que �
% segmenta��o. Por isso vamos mostrar apenas as regi�es disjuntas sem levar
% em considera��o a nova cor para qual cada pixel foi remapeado. Em redu��o
% de cores (quantiza��o) pra visualiza��o, codifica��o e feature
% extraction isso seria importante. Mas pra segmenta��o n�o. Portanto:
figure, imshow(x1,[]), title('x1')

figure, scatter3(map1(:,1), map1(:,2), map1(:,3), 100, map1, 'filled')
title('map1')
xlim([0 1]), ylim([0 1]), zlim([0 1])
xlabel('R'), ylabel('G'), zlabel('B')

%allColors32: como tem todas as cores, cmunique tem 8 ou 27 cores
%shark1: nem todas as cores existiam na original, ent�o cmunique d� apenas 5
%para 8 cores e 11 para 27 cores.