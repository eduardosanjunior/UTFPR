% color_19 [script]

clear all; close all; clc

rgb = imread('hotwheels09m.png');
figure, imshow(rgb)
nr = size(rgb, 1);
nc = size(rgb, 2);

hsv = rgb2hsv(rgb);
h = hsv(:,:,1);
s = hsv(:,:,2);
v = hsv(:,:,3);

hsv_crop = hsv(155:169,155:169,:);

h_crop = hsv_crop(:,:,1);
s_crop = hsv_crop(:,:,2);

hL = (h > 0.95) | (h < 0.01);
sL = (s > 0.7);

figure, imshow(hL);
figure, imshow(sL);

R = hL & sL;
figure, imshow(R);