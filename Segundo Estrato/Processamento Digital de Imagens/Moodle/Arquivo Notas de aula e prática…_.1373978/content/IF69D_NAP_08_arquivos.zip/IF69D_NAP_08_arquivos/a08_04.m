% a08_04 [script]

clear all; close all; clc

g = imread('whitecells4.png');
th = graythresh(g);
bw = im2bw(g, th);
figure, imshow(g)
figure, imshow(bw)

[L, n] = bwlabel(bw, 8);

disp(['Tem ' num2str(n) ' c�lulas'])

% Visualisando L em gray
Lg = mat2gray(L);
figure, imshow(Lg)

% Visualisando L com pseudocores
Lrgb = label2rgb(L);
figure, imshow(Lrgb)