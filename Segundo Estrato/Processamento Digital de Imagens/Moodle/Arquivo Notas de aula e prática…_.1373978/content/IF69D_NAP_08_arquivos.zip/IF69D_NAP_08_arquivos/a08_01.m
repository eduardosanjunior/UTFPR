% a08_01 [script]

clear all; close all; clc

% Observar que o th � autom�tico, i.e.,
% diferente para cada imagem

g1 = imread('psl1_gray.png');
th = graythresh(g1)
bw1 = im2bw(g1, th);
figure
subplot(1,2,1), imshow(g1)
subplot(1,2,2), imshow(bw1)

g2 = imread('psl2_gray.png');
th = graythresh(g2)
bw2 = im2bw(g2, th);
figure
subplot(1,2,1), imshow(g2)
subplot(1,2,2), imshow(bw2)

g3 = imread('psl3_gray.png');
th = graythresh(g3)
bw3 = im2bw(g3, th);
figure
subplot(1,2,1), imshow(g3)
subplot(1,2,2), imshow(bw3)