% a08_03 [script]

clear all; close all; clc

g1 = imread('psl1_gray.png');
th = graythresh(g1);
bw1 = im2bw(g1, th);
bw1 = ~bw1; %inverte
% Morfologia
SE = strel('square', 5);
bw1m1 = imclose(bw1,SE);
bw1m2 = imopen(bw1m1,SE);
% Mostra
figure
subplot(1,3,1), imshow(g1)
subplot(1,3,2), imshow(bw1)
subplot(1,3,3), imshow(bw1m2)

g2 = imread('psl2_gray.png');
th = graythresh(g2);
bw2 = im2bw(g2, th);
bw2 = ~bw2; %inverte
% Morfologia
SE = strel('square', 5);
bw2m1 = imclose(bw2,SE);
bw2m2 = imopen(bw2m1,SE);
% Mostra
figure
subplot(1,3,1), imshow(g2)
subplot(1,3,2), imshow(bw2)
subplot(1,3,3), imshow(bw2m2)

g3 = imread('psl3_gray.png');
th = graythresh(g3);
bw3 = im2bw(g3, th);
bw3 = ~bw3; %inverte
% Morfologia
SE = strel('square', 5);
bw3m1 = imclose(bw3,SE);
bw3m2 = imopen(bw3m1,SE);
% Mostra
figure
subplot(1,3,1), imshow(g3)
subplot(1,3,2), imshow(bw3)
subplot(1,3,3), imshow(bw3m2)

% �rea das regi�es
% 1) Podemos simplesmente somar todos os uns da imagem, pois
% garantimos que h� apenas um componente conexo.
areasS(1) = sum(bw1m2(:));
areasS(2) = sum(bw2m2(:));
areasS(3) = sum(bw3m2(:));
[m, i] = max(areasS);
disp(['Maior �rea: imagem ' num2str(i)]);
disp(['�rea = ' num2str(m)]);

% 2) Usando o bwlabel
[L n] = bwlabel(bw1m2, 8);
linearIdx = find(L==1); %1 � o label do objeto
areasL(1) = length(linearIdx);
[L n] = bwlabel(bw2m2, 8);
linearIdx = find(L==1); %1 � o label do objeto
areasL(2) = length(linearIdx);
[L n] = bwlabel(bw3m2, 8);
linearIdx = find(L==1); %1 � o label do objeto
areasL(3) = length(linearIdx);
[m, i] = max(areasL);
disp(['Maior �rea: imagem ' num2str(i)]);
disp(['�rea = ' num2str(m)])