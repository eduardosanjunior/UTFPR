% a08_07 [script]

clear all; close all; clc

g = imread('arroz.png');
figure, imshow(g); title('g')

t = graythresh(g);
bw = im2bw(g, t);
figure, imshow(bw), title('bw')

%observe que os gr�os da parte inferior n�o s�o
%mantidos na imagem limiarizada

SE = strel('disk',15,0);
ge = imerode(g, SE);
figure, imshow(ge); title('ge')
ged = imdilate(ge, SE);%resultado da abertura
figure, imshow(ged); title('ged') %resultado da abertura

gtophat = imsubtract(g, ged);
figure, imshow(gtophat); title('gtophat')
tophat = imtophat(g, SE);
figure, imshow(tophat); title('func tophat() para comparar')

gtophat_bw = im2bw(gtophat, graythresh(gtophat));
figure, imshow(gtophat_bw); title('gtophat\_bw')
tophat_bw = im2bw(tophat, graythresh(tophat));
figure, imshow(tophat_bw); title('func tophat()\_bw para comparar')