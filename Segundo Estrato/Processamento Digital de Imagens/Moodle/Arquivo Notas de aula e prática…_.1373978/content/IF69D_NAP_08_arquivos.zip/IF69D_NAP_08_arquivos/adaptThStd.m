function y = adaptThStd(x)
% x: bloco da imagem (subimagem)
% y: bloco processado

if(std2(x)) < 1 % sem texto -> � fundo
    y = ones(size(x,1),size(x,2)); % sai um bloco de uns
else % caso contr�rio
    y = im2bw(x, graythresh(x)); % aplica Otsu no bloco
end

