% a08_06 [script]

clear all; close all; clc

g = imread('whitecells4.png');
th = graythresh(g);
bw = im2bw(g, th);
figure, imshow(g)
figure, imshow(bw)

 % Labeling
[rv8, nobj] = bwlabel(bw, 8);

% Aloca vetor para armazenar o n�mero de pixels de cada objeto
area = zeros(1,nobj);
% Aloca cell array para armazenar os �ndices lineares de cada objeto
linearIdx = cell(1,nobj);

% Para cada objeto
for k = 1:nobj
    % Coordenadas lineares dos pixels do objeto k
    linearIdx{k} = find(rv8==k);
    % N�mero de pixels do objeto k
    area(k) = length(linearIdx{k});
end

[ordenado, indexes] = sort(area); %indexes � o label

% Apenas as 70% menores �reas
nobj2 = nobj*0.7;
ordenado = ordenado(1:uint8(nobj2));
indexes = indexes(1:uint8(nobj2));

% Elimina os 70% objetos menores
bw2 = bw;
for k = 1:length(ordenado)
    bw2(linearIdx{indexes(k)}) =  0;
end

figure, imshow(bw2)