% a04_01 [script]

%gu = imread('xray01.png');
gu = imread('grays8bit.png');
figure; imshow(gu)

%gu = im2uint8(g);

%Fun��o de transforma��o
y = uint8(255:-1:0);
figure;
plot(y); xlim([0 255]); ylim([0 255]);
gu1 = double(gu)+1;

gt = y(gu1);
figure, imshow(gt)