export class Usuario
{
    id: number;
    nome: string;
    nascimento: string;
    email: string;
    senha: string;
}