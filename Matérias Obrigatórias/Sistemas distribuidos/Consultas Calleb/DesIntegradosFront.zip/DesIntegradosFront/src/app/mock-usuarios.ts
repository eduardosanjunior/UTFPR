import {Usuario} from './usuario';

export const USUARIOS: Usuario[] = [

    {
        id: 1,
        nome: "Dayton Stanton",
        nascimento: "2011-12-22T20:15:36.9320081-02:00",
        email: "DaytonStanton17@gmail.com",
        senha: "WnuiwUCnZz"
      },
      {
        "id": 2,
        "nome": "Omer Walker",
        "nascimento": "2010-07-13T15:21:37.9887001-03:00",
        "email": "OmerWalker40@yahoo.com",
        "senha": "JSZFrs6n4J"
      },
      {
        "id": 3,
        "nome": "Linnea Moen",
        "nascimento": "2012-04-22T09:40:44.008537-03:00",
        "email": "LinneaMoen29@hotmail.com",
        "senha": "MaNjEa2LkV"
      },
      {
        "id": 4,
        "nome": "Pascale Hilpert",
        "nascimento": "2002-04-30T01:17:51.7083867-03:00",
        "email": "PascaleHilpert_Pollich@hotmail.com",
        "senha": "TMevU3lBEw"
      },
      {
        "id": 5,
        "nome": "Aryanna Kuhic",
        "nascimento": "2014-02-15T08:40:52.0851573-02:00",
        "email": "AryannaKuhic98@yahoo.com",
        "senha": "oOMSYCUXph"
      },
      {
        "id": 6,
        "nome": "Sarina Smitham",
        "nascimento": "1998-12-16T05:41:06.6856948-02:00",
        "email": "SarinaSmitham82@yahoo.com",
        "senha": "IvNDnYCDRN"
      },
      {
        "id": 7,
        "nome": "Stephania Swift",
        "nascimento": "2017-12-14T11:11:25.3074001-02:00",
        "email": "StephaniaSwift53@hotmail.com",
        "senha": "9flK4ELEP6"
      },
      {
        "id": 8,
        "nome": "Michele Abshire",
        "nascimento": "1995-01-04T12:09:40.0454668-02:00",
        "email": "MicheleAbshire5@hotmail.com",
        "senha": "AqiP0gx_DB"
      },
      {
        "id": 9,
        "nome": "Wendell O'Kon",
        "nascimento": "1996-07-12T22:31:45.4167566-03:00",
        "email": "WendellOKon_Hauck@yahoo.com",
        "senha": "46SRSWUg4r"
      },
      {
        "id": 10,
        "nome": "Eleonore Tremblay",
        "nascimento": "2008-05-07T05:53:57.9560643-03:00",
        "email": "EleonoreTremblay48@yahoo.com",
        "senha": "8ZZg8NA7es"
      }
];