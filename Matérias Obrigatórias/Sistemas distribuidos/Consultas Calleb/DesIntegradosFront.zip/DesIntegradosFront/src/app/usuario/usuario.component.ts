import { Component, OnInit } from '@angular/core';
import { Usuario} from '../usuario';
import {UsuarioService} from '../usuario.service';

@Component({
  selector: 'app-usuario',
  templateUrl: './usuario.component.html',
  styleUrls: ['./usuario.component.css']
})
export class UsuarioComponent implements OnInit {
  usuarios: Usuario[];
  selectedUser: Usuario;

  constructor(private usuarioService: UsuarioService) { }

  getUsers(): void
  {
      this.usuarioService.getUsers().subscribe(usuarios => this.usuarios = usuarios);
  }

  ngOnInit() {
    this.getUsers();
  }

  onSelect(user: Usuario): void {
    this.selectedUser = user;
  }
}
